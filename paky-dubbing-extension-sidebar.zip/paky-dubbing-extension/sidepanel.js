/* PAKY Dubbing – side panel logic (UI เท่านั้น ยังไม่ต่อ backend) */
(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const popup = $('popup');

  /* ------------------------------------------------------------------
     Scale: ดีไซน์กว้าง 314px -> ขยายให้เต็มความกว้าง side panel
     (ผู้ใช้ลากปรับความกว้าง panel ได้ ตัวอักษรจะใหญ่ตามอัตโนมัติ)
     ------------------------------------------------------------------ */
  const DESIGN_W = 314;
  const MIN_SCALE = 1, MAX_SCALE = 2.4;
  function applyScale() {
    const z = Math.max(MIN_SCALE, Math.min(MAX_SCALE, window.innerWidth / DESIGN_W));
    document.body.style.zoom = z;
  }
  applyScale();
  window.addEventListener('resize', applyScale);

  /* ------------------------------------------------------------------
     ข้อมูลตัวเลือก dropdown – เพิ่มได้ที่นี่
     ------------------------------------------------------------------ */
  const FROM_LANGS = [{ value: 'en', label: 'english' }];
  const TO_LANGS   = [{ value: 'th', label: 'ไทย' }];
  const VOICES     = [{ value: 'th-TH-PremwadeeNeural', label: 'Sawadee Online (Naural) - Female' }];

  /* ------------------------------------------------------------------
     States  (ตรงกับ Frame 1-4)
       login = Frame 1 | free = Frame 2 | trial = Frame 3 | paid = Frame 4
     ------------------------------------------------------------------ */
  const STATES = {
    free: {
      active: 'A',
      btnA: ['used', 'Used'],
      btnB: ['trial', 'free trial'],
      tier: 'Free',
      pct: '100%',
      fill: '100%',
      sub: 'Unlimited',
      subRight: 31,
      upg: null,
    },
    trial: {
      active: 'B',
      btnA: ['use', 'Use'],
      btnB: ['used', 'Used'],
      tier: 'free trial',
      pct: '58%',
      fill: '165px',
      sub: '<b>2.8</b> minutes of video left.',
      subRight: 25,
      upg: ['on', 'Upgrade'],
    },
    paid: {
      active: 'B',
      btnA: ['use', 'Use'],
      btnB: ['used', 'Used'],
      tier: 'upgrade tier',
      pct: '69%',
      fill: '200px',
      sub: '<b>132.6</b> minutes of video left, For this day.',
      subRight: 25,
      upg: ['off', 'Expired in 7 days'],
    },
  };

  function setBtn(el, [kind, text]) {
    el.className = 'abs cbtn ' + kind;
    el.textContent = text;
  }

  function setState(name) {
    if (name !== 'login' && !STATES[name]) name = 'login';
    popup.classList.remove('s-login', 's-free', 's-trial', 's-paid');
    popup.classList.add('s-' + name);
    popup.dataset.state = name;
    if (name === 'login') return;

    const s = STATES[name];
    $('cardA').classList.toggle('on', s.active === 'A');
    $('cardB').classList.toggle('on', s.active === 'B');
    setBtn($('btnA'), s.btnA);
    setBtn($('btnB'), s.btnB);

    $('crTier').textContent = s.tier;
    $('crPct').textContent = s.pct;
    $('barFill').style.setProperty('--w', s.fill);

    const sub = $('crSub');
    sub.innerHTML = s.sub;
    sub.style.right = s.subRight + 'px';

    const upg = $('btnUpg');
    if (s.upg) {
      upg.className = 'abs upg ' + s.upg[0];
      upg.textContent = s.upg[1];
    }
  }

  /* ------------------------------------------------------------------
     Login
     ------------------------------------------------------------------ */
  const email = $('email'), pass = $('pass');
  const syncPh = () => {
    $('phEmail').classList.toggle('hide', email.value !== '');
    $('phPass').classList.toggle('hide', pass.value !== '');
  };
  email.addEventListener('input', syncPh);
  pass.addEventListener('input', syncPh);

  $('btnSignIn').addEventListener('click', () => setState('free'));
  $('btnGoogle').addEventListener('click', () => setState('free'));
  $('lnkForget').addEventListener('click', (e) => e.preventDefault());
  pass.addEventListener('keydown', (e) => { if (e.key === 'Enter') setState('free'); });

  /* ------------------------------------------------------------------
     Plan buttons
     ------------------------------------------------------------------ */
  $('btnA').addEventListener('click', () => {
    if ($('btnA').classList.contains('use')) setState('free');
  });
  $('btnB').addEventListener('click', () => {
    if ($('btnB').classList.contains('trial')) setState('trial');
  });
  $('btnUpg').addEventListener('click', () => {
    if ($('btnUpg').classList.contains('on')) setState('paid');
  });

  ['lnkRate', 'lnkSite'].forEach((id) =>
    $(id).addEventListener('click', (e) => e.preventDefault())
  );

  /* ------------------------------------------------------------------
     Dropdowns (ใช้ <select> โปร่งใสซ้อนบนปุ่มทรงแคปซูล)
     ------------------------------------------------------------------ */
  function bindSelect(selId, textId, items) {
    const sel = $(selId), txt = $(textId);
    items.forEach((o) => {
      const opt = document.createElement('option');
      opt.value = o.value;
      opt.textContent = o.label;
      sel.appendChild(opt);
    });
    const sync = () => { txt.textContent = sel.options[sel.selectedIndex].textContent; };
    sel.addEventListener('change', sync);
    sync();
  }
  bindSelect('selFrom', 'fromTxt', FROM_LANGS);
  bindSelect('selTo', 'toTxt', TO_LANGS);
  bindSelect('selVoice', 'voiceTxt', VOICES);

  /* ------------------------------------------------------------------
     Volume sliders
     กล่อง slider กว้าง 138 (ตามรูป), thumb กว้าง 18 รวมขอบม่วง -> วิ่งได้ 120px
     ------------------------------------------------------------------ */
  const TRAVEL = 120;
  const SLIDER_W = 138;

  function makeSlider({ el, pctEl, muteEl, loudEl, value }) {
    const thumb = el.querySelector('.thumb');
    let v = value;

    const render = () => {
      thumb.style.setProperty('--l', (v / 100) * TRAVEL + 'px');
      pctEl.textContent = Math.round(v) + '%';
    };

    const fromEvent = (e) => {
      const r = el.getBoundingClientRect();
      const k = r.width / SLIDER_W;               // ชดเชย zoom ของ body
      const x = (e.clientX - r.left) / k - 8;     // กึ่งกลาง thumb
      v = Math.max(0, Math.min(100, (x / TRAVEL) * 100));
      render();
    };

    el.addEventListener('pointerdown', (e) => {
      el.setPointerCapture(e.pointerId);
      fromEvent(e);
      const move = (ev) => fromEvent(ev);
      const up = () => {
        el.removeEventListener('pointermove', move);
        el.removeEventListener('pointerup', up);
        el.removeEventListener('pointercancel', up);
      };
      el.addEventListener('pointermove', move);
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
    });

    muteEl.addEventListener('click', () => { v = 0; render(); });
    loudEl.addEventListener('click', () => { v = 100; render(); });
    render();
  }

  makeSlider({ el: $('slVideo'), pctEl: $('pcVideo'), muteEl: $('vMute'), loudEl: $('vLoud'), value: 0 });
  makeSlider({ el: $('slDub'),   pctEl: $('pcDub'),   muteEl: $('dMute'), loudEl: $('dLoud'), value: 100 });

  /* ------------------------------------------------------------------
     เริ่มต้น: Frame 1 (login)
     ดูแต่ละเฟรมตรงๆ ได้ด้วย hash:  sidepanel.html#login | #free | #trial | #paid
     ------------------------------------------------------------------ */
  const initial = (location.hash || '').replace('#', '');
  setState(initial || 'login');
  window.addEventListener('hashchange', () => setState(location.hash.replace('#', '')));
})();
