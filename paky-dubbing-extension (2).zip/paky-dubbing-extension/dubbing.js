/* =========================================================
   PAKY Dubbing — dubbing.js
   ระบบเบื้องหลังทั้งหมดของ dub.html (ไม่มี UI)

   - ตรรกะ: cleanTranscriptText → splitIntoSentences → autoPunctuate →
     cleanAndGroupSegments → fetchTranscript → TTS (calibrate/ticker/rate)
     → translateAll  ถูกคัดลอกจากต้นฉบับแบบ verbatim
   - จุดที่ต่างจากต้นฉบับมีเพียง: (1) ตัดโค้ดที่แตะ DOM แล้วส่ง event แทน
     (2) fetch ผ่าน background (กัน CORS/CSP ของ youtube.com)
     (3) localStorage -> chrome.storage (ไม่ไปเขียน storage ของ youtube.com)
     (4) เพิ่ม S.vol (ระดับเสียงพากย์), translateAll(startFrom), exports
   - เปิดใช้งานผ่าน window.PakyDubbing.init()
========================================================= */
(() => {
'use strict';

/* ---------- extension glue (ไม่ใช่ logic เดิม) ---------- */

const listeners = new Map();
function emit(type, data) {
    (listeners.get(type) || []).forEach(fn => { try { fn(data); } catch (e) { console.error(e); } });
}
function on(type, fn) {
    if (!listeners.has(type)) listeners.set(type, []);
    listeners.get(type).push(fn);
}

/* fetch ผ่าน background service worker (host_permissions) */
function netFetch(url, init = {}) {
    const { method = "GET", headers, cache } = init;
    return new Promise((resolve, reject) => {
        try {
            chrome.runtime.sendMessage(
                { type: "paky:fetch", url, init: { method, headers, cache } },
                res => {
                    const err = chrome.runtime.lastError;
                    if (err) return reject(new Error(err.message));
                    if (!res || res.error) return reject(new Error((res && res.error) || "Failed to fetch"));
                    resolve({
                        ok: res.ok,
                        status: res.status,
                        json: async () => JSON.parse(res.text),
                        text: async () => res.text
                    });
                }
            );
        } catch (e) { reject(new Error("Failed to fetch")); }
    });
}

/* แทน localStorage (sync API เดิม) ด้วย cache ที่ hydrate จาก chrome.storage.local */
const STORE_PREFIX = "paky:";
const storeCache = {};
const store = {
    getItem(k) { return Object.prototype.hasOwnProperty.call(storeCache, k) ? storeCache[k] : null; },
    setItem(k, v) {
        storeCache[k] = String(v);
        try { chrome.storage.local.set({ [STORE_PREFIX + k]: String(v) }); } catch (e) { }
    }
};
async function hydrateStore() {
    try {
        const all = await chrome.storage.local.get(null);
        for (const key of Object.keys(all)) {
            if (key.startsWith(STORE_PREFIX)) storeCache[key.slice(STORE_PREFIX.length)] = all[key];
        }
    } catch (e) { }
}

/* UI stub: ให้โค้ด TTS เดิมที่อ้าง el.* ทำงานต่อได้โดยไม่มี DOM */
function makeHeadlessEl() {
    const warnState = { v: false };
    const node = () => ({
        value: "", max: "0", disabled: false, textContent: "", innerHTML: "", style: {},
        classList: { toggle() {}, add() {}, remove() {} },
        addEventListener() {}, appendChild() {}
    });
    const info = node();
    let infoText = "";
    Object.defineProperty(info, "textContent", {
        get() { return infoText; },
        set(v) { infoText = v; emit("info", { text: v, warn: warnState.v }); }
    });
    info.classList = { toggle(_c, on_) { warnState.v = !!on_; }, add() {}, remove() {} };
    return { bar: node(), play: node(), stop: node(), seek: node(), time: node(),
             voice: node(), trans: node(), source: node(), info };
}

function highlightSegment(index) { emit("active", index); }

/* =========================================================
   CONFIG
========================================================= */

const API_BASE =
    "https://youtubegpt.ai/api/transcript";


/* =========================================================
   STATE
========================================================= */

let currentVideoId = "";

let currentData = null;

let currentRawSegments = [];

let currentSegments = [];

let currentFullText = "";

let currentLanguage = "";


/* =========================================================
   VIDEO ID
========================================================= */

function getVideoId(
    input
) {

    try {

        const url =
            new URL(input);

        const host =
            url.hostname
                .toLowerCase();


        if (
            host ===
            "youtu.be"
        ) {

            return (
                url.pathname
                    .split("/")
                    .filter(Boolean)[0]
                || null
            );
        }


        const videoId =
            url.searchParams.get(
                "v"
            );


        if (
            videoId
        ) {

            return videoId;
        }


        const match =
            url.pathname.match(
                /\/(?:shorts|embed|live)\/([^/?]+)/
            );


        if (
            match
        ) {

            return match[1];
        }


        return null;

    } catch {

        return null;
    }
}


/* =========================================================
   FORMAT TIME
========================================================= */

function formatTime(
    milliseconds,
    precise = true
) {

    let ms =
        Math.max(
            0,
            Number(
                milliseconds
            ) || 0
        );


    const totalSeconds =
        Math.floor(
            ms / 1000
        );


    const remainMs =
        Math.floor(
            ms % 1000
        );


    const hours =
        Math.floor(
            totalSeconds /
            3600
        );


    const minutes =
        Math.floor(
            (
                totalSeconds %
                3600
            ) / 60
        );


    const seconds =
        totalSeconds % 60;


    if (
        hours > 0
    ) {

        if (
            precise
        ) {

            return (
                String(hours).padStart(
                    2,
                    "0"
                ) +
                ":" +
                String(minutes).padStart(
                    2,
                    "0"
                ) +
                ":" +
                String(seconds).padStart(
                    2,
                    "0"
                ) +
                "." +
                String(remainMs).padStart(
                    3,
                    "0"
                )
            );
        }


        return (
            String(hours).padStart(
                2,
                "0"
            ) +
            ":" +
            String(minutes).padStart(
                2,
                "0"
            ) +
            ":" +
            String(seconds).padStart(
                2,
                "0"
            )
        );
    }


    if (
        precise
    ) {

        return (
            String(minutes).padStart(
                2,
                "0"
            ) +
            ":" +
            String(seconds).padStart(
                2,
                "0"
            ) +
            "." +
            String(remainMs).padStart(
                3,
                "0"
            )
        );
    }


    return (
        String(minutes).padStart(
            2,
            "0"
        ) +
        ":" +
        String(seconds).padStart(
            2,
            "0"
        )
    );
}


/* =========================================================
   SRT TIME
========================================================= */

function formatSrtTime(
    milliseconds
) {

    const ms =
        Math.max(
            0,
            Number(
                milliseconds
            ) || 0
        );


    const totalSeconds =
        Math.floor(
            ms / 1000
        );


    const remainMs =
        Math.floor(
            ms % 1000
        );


    const hours =
        Math.floor(
            totalSeconds / 3600
        );


    const minutes =
        Math.floor(
            (
                totalSeconds %
                3600
            ) / 60
        );


    const seconds =
        totalSeconds % 60;


    return (
        String(hours).padStart(
            2,
            "0"
        ) +
        ":" +
        String(minutes).padStart(
            2,
            "0"
        ) +
        ":" +
        String(seconds).padStart(
            2,
            "0"
        ) +
        "," +
        String(remainMs).padStart(
            3,
            "0"
        )
    );
}


/* =========================================================
   CLEAN TEXT

   RULE:
   [...] → remove

   Example:
   "Hello [INAUDIBLE] world"
   →
   "Hello world"
========================================================= */

function cleanTranscriptText(text) {

    if (typeof text !== "string") {
        return "";
    }

    let cleaned = text;

    /* 1) ลบ [...] และ (...) ทั้งก้อน เช่น [Music] (applause) */
    cleaned = cleaned
        .replace(/\[[^\]]*\]/g, " ")
        .replace(/\([^)]*\)/g, " ")
        .replace(/（[^）]*）/g, " ");

    /* 2) ... และ … → . */
    cleaned = cleaned
        .replace(/…/g, ".")
        .replace(/\.{2,}/g, ".");

    /* 3) ' แบบโค้งให้เป็นแบบตรงก่อน (กัน don't / it's พัง) */
    cleaned = cleaned.replace(/[’‘]/g, "'");

    /* 4) ลบสัญลักษณ์ทั้งหมด (>>, >>>, -, –, —, ♪, ", :, ; ฯลฯ)
          เก็บไว้เฉพาะ: ตัวอักษรทุกภาษา, เครื่องหมายสระ/วรรณยุกต์ไทย,
          ตัวเลข, ช่องว่าง และ ? ! . , '  */
    cleaned = cleaned.replace(
        /[^\p{L}\p{M}\p{N}\s.,?!']/gu,
        " "
    );

    /* 5) ' ที่ไม่ได้อยู่กลางคำ (เช่น 'hello') ให้ลบ */
    cleaned = cleaned.replace(
        /(?<!\p{L})'|'(?!\p{L})/gu,
        " "
    );

    /* 6) ช่องว่าง */
    cleaned = cleaned.replace(/\s+/g, " ");

    /* 7) ลบช่องว่างก่อนเครื่องหมาย , ? . ! */
    cleaned = cleaned.replace(/\s+([,?.!])/g, "$1");

    /* 8) ! ท้ายประโยค → . */
    cleaned = cleaned.replace(/!+(?=\s|$)/g, ".");

    /* 9) ?! / !? → ? */
    cleaned = cleaned.replace(/\?+(?:\.+)?/g, "?");

    /* 10) เครื่องหมายซ้ำ เช่น ",," → "," */
    cleaned = cleaned.replace(/,{2,}/g, ",");

    cleaned = cleaned.trim();

    /* 11) ถ้าไม่เหลือตัวอักษร/ตัวเลขเลย (เช่น cue ที่มีแค่ ">> ...") ให้ทิ้งทั้ง cue */
    if (!/[\p{L}\p{N}]/u.test(cleaned)) {
        return "";
    }

    return cleaned;
}


/* =========================================================
   ABBREVIATIONS

   Prevent:

   Mr.
   Dr.
   Prof.
   etc.

   from being treated as sentence endings.
========================================================= */

const ABBREVIATIONS =
    new Set([

        "mr",
        "mrs",
        "ms",
        "mx",

        "dr",
        "prof",
        "sr",
        "jr",

        "st",
        "vs",
        "etc",

        "e.g",
        "i.e",

        "u.s",
        "u.k",

        "approx",
        "dept",
        "inc",
        "ltd",
        "jan",
        "feb",
        "mar",
        "apr",
        "jun",
        "jul",
        "aug",
        "sep",
        "sept",
        "oct",
        "nov",
        "dec"
    ]);


/* =========================================================
   CHECK ABBREVIATION
========================================================= */

function isAbbreviationBefore(
    text,
    periodIndex
) {

    const before =
        text.slice(
            0,
            periodIndex
        );


    const match =
        before.match(
            /([A-Za-z](?:[A-Za-z.]*)?)$/
        );


    if (
        !match
    ) {

        return false;
    }


    const token =
        match[1]
            .toLowerCase()
            .replace(
                /\.$/,
                ""
            );


    return ABBREVIATIONS.has(
        token
    );
}


/* =========================================================
   FIND SENTENCE BOUNDARIES
========================================================= */

function findSentenceBoundaries(
    text
) {

    const boundaries = [];


    for (
        let i = 0;
        i < text.length;
        i++
    ) {

        const char =
            text[i];


        /*
            ? or .
        */

        if (
            char !== "." &&
            char !== "?"
        ) {

            continue;
        }


        /*
            Skip decimal:

            3.14
        */

        const previous =
            text[i - 1];

        const next =
            text[i + 1];


        if (
            char === "." &&
            /\d/.test(previous || "") &&
            /\d/.test(next || "")
        ) {

            continue;
        }


        /*
            Skip abbreviation.
        */

        if (
            char === "." &&
            isAbbreviationBefore(
                text,
                i
            )
        ) {

            continue;
        }


        /*
            Skip dot sequences
        */

        if (
            next === "."
        ) {

            continue;
        }


        /*
            Find first non-space character
            after punctuation.
        */

        let nextIndex =
            i + 1;


        while (
            nextIndex <
                text.length &&
            /\s/.test(
                text[nextIndex]
            )
        ) {

            nextIndex++;
        }


        /*
            End of string = sentence end
        */

        if (
            nextIndex >=
            text.length
        ) {

            boundaries.push(
                i + 1
            );

            continue;
        }


        /*
            For question marks:
            always treat as a boundary.
        */

        if (
            char === "?"
        ) {

            boundaries.push(
                nextIndex
            );

            continue;
        }


        /*
            For periods:
            usually a new sentence starts
            with uppercase/digit/quote.
        */

        const nextChar =
            text[nextIndex];


        if (
            /[A-Z0-9"'“‘(\-]/.test(
                nextChar
            )
        ) {

            boundaries.push(
                i + 1
            );

            continue;
        }


        /*
            Lowercase continuation:
            don't split.

            Example:
            "e.g. this"
        */

    }


    return boundaries;
}


/* =========================================================
   SPLIT SENTENCES

   This ensures one final cue won't contain
   multiple sentence endings.
========================================================= */

function splitIntoSentences(
    text
) {

    if (
        !text
    ) {

        return [];
    }


    const boundaries =
        findSentenceBoundaries(
            text
        );


    if (
        boundaries.length === 0
    ) {

        return [
            text.trim()
        ];
    }


    const sentences = [];

    let start =
        0;


    for (
        const boundary of
        boundaries
    ) {

        const piece =
            text
                .slice(
                    start,
                    boundary
                )
                .trim();


        if (
            piece
        ) {

            sentences.push(
                piece
            );
        }


        start =
            boundary;
    }


    const remainder =
        text
            .slice(
                start
            )
            .trim();


    if (
        remainder
    ) {

        sentences.push(
            remainder
        );
    }


    return sentences
        .filter(Boolean);
}


/* =========================================================
   CHECK SENTENCE END
========================================================= */

function endsSentence(
    text
) {

    if (
        !text
    ) {

        return false;
    }


    return /[?.]$/.test(
        text.trim()
    );
}


/* =========================================================
   TEXT WEIGHT
========================================================= */

function sentenceWeight(
    text
) {

    /*
        Weight using words first,
        characters second.
    */

    const words =
        text
            .trim()
            .split(
                /\s+/
            )
            .filter(Boolean)
            .length;


    const chars =
        text
            .replace(
                /\s+/g,
                ""
            )
            .length;


    return Math.max(
        1,
        words * 10 +
        chars
    );
}


/* =========================================================
   SPLIT A RAW CUE WITH ESTIMATED TIMINGS

   Example:

   Raw:

   start = 0
   dur = 10200

   "Hello world. How are you?"

   →

   0
   Hello world.

   estimatedStart
   How are you?
========================================================= */

function splitCueWithEstimatedTiming(
    cue,
    nextRawStart = null
) {

    const sentences =
        splitIntoSentences(
            cue.text
        );


    /*
        No split necessary.
    */

    if (
        sentences.length <= 1
    ) {

        return [

            {
                start:
                    cue.start,

                dur:
                    cue.dur,

                end:
                    cue.end,

                text:
                    cue.text,

                estimated:
                    false
            }

        ];
    }


    /*
        Determine timeline range.

        Prefer the next raw cue's start
        because raw caption streams can
        overlap.

        Example:

        current:
        00:00 + 10.20

        next:
        00:05.240

        The useful internal window is
        00:00 → 00:05.240
    */

    let span = 0;


    if (
        nextRawStart != null &&
        nextRawStart >
            cue.start
    ) {

        span =
            nextRawStart -
            cue.start;

    } else if (
        cue.dur != null &&
        cue.dur > 0
    ) {

        span =
            cue.dur;

    } else {

        /*
            Last-resort estimate.
        */

        span =
            sentences.length *
            2000;
    }


    /*
        Calculate sentence weights.
    */

    const weights =
        sentences.map(
            sentenceWeight
        );


    const totalWeight =
        weights.reduce(
            (sum, weight) =>
                sum + weight,
            0
        );


    const result = [];

    let elapsed = 0;


    sentences.forEach(
        (
            sentence,
            index
        ) => {

            const isLast =
                index ===
                sentences.length - 1;


            let duration;


            if (
                isLast
            ) {

                /*
                    Final piece receives all
                    remaining time.

                    This prevents rounding drift.
                */

                duration =
                    span -
                    elapsed;

            } else {

                duration =
                    Math.round(
                        span *
                        (
                            weights[index] /
                            totalWeight
                        )
                    );
            }


            duration =
                Math.max(
                    1,
                    duration
                );


            const start =
                cue.start +
                elapsed;


            result.push({

                start,

                dur:
                    duration,

                end:
                    start +
                    duration,

                text:
                    sentence,

                estimated:
                    true
            });


            elapsed +=
                duration;
        }
    );


    return result;
}


/* =========================================================
   AUTO PUNCTUATION  (STEP 0)

   ใช้เมื่อ transcript แทบไม่มี . ? ! เลย
   (พบบ่อยใน auto-generated captions)

   1) ตรวจว่า "ขาดเครื่องหมายจริงไหม"
   2) ถ้าใช่ เติม "." ท้าย cue ที่คาดว่าเป็นท้ายประโยค
      โดยเดาจาก:
        - ช่องว่างระหว่าง cue (pause)
        - ความยาวข้อความที่สะสม
        - ระยะเวลาที่สะสม (timeline)
========================================================= */

const AUTO_PUNCT = {

    enabled: true,

    /* เงื่อนไขตรวจจับ */
    minCues: 8,                 // cue น้อยกว่านี้ไม่ตรวจ
    maxTerminatorsPerCue: 0.08, // มี . ? ! น้อยกว่า 0.08 ต่อ cue = ถือว่าขาด

    /*
        เงื่อนไขตัดประโยค — ตั้งให้ "ระวัง" ไว้ก่อน
        (ตัดน้อยไปดีกว่าตัดกลางประโยคที่ยังพูดไม่จบ)
    */
    minChars: 30,               // สั้นกว่านี้ไม่ตัด (ยกเว้นเงียบนานมาก)
    softChars: 140,             // ยาวระดับนี้ → ยอมตัดที่ pause ที่เบาลง
    softMs: 8000,               // นานระดับนี้ → ยอมตัดที่ pause ที่เบาลง

    /*
        กรณี dur ของ cue เชื่อถือได้ (ไม่ซ้อนทับ cue ถัดไป)
        → ใช้ช่องว่างจริง next.start − (start+dur)
    */
    gap: {
        pauseMs: 650,
        softPauseMs: 400,
        bigPauseMs: 2000
    },

    /*
        กรณี dur ซ้อนทับกัน (เชื่อถือไม่ได้)
        → ประมาณ pause จากความยาวข้อความ ซึ่งมี noise สูง
        จึงตั้งเกณฑ์สูงกว่ามากเพื่อกันตัดกลางประโยค
    */
    estimated: {
        pauseMs: 1300,
        softPauseMs: 800,
        bigPauseMs: 3000
    },

    reliableDurRatio: 0.8,      // cue ที่ไม่ซ้อนทับ ≥ 80% ถึงถือว่า dur เชื่อถือได้
    hardChars: 360,             // เพดานกันก้อนยักษ์ (ไม่ใช่กฎปกติ)
    hardMs: 20000,
    msPerCharMin: 20,           // ขอบเขตของความเร็วพูดที่ประมาณได้ (ms ต่อตัวอักษร)
    msPerCharMax: 200
};


/*
    คำที่ "ไม่ควรเป็นคำสุดท้ายของประโยค" (อังกฤษ)
    ถ้า cue ลงท้ายด้วยคำพวกนี้ แปลว่ายังพูดไม่จบ → ไม่ตัด
*/

const DANGLING_WORDS =
    new Set([

        "and", "but", "or", "so", "because", "although", "though",
        "if", "when", "while", "where", "which", "who", "whom",
        "whose", "than", "then", "as", "the", "a", "an", "to", "of",
        "in", "on", "at", "for", "with", "from", "by", "into",
        "is", "are", "was", "were", "be", "been", "am", "have",
        "has", "had", "will", "would", "could", "should", "can",
        "my", "your", "our", "their", "his", "her", "its", "not",
        "also", "very", "about"
    ]);


function endsWithDanglingWord(
    text
) {

    const m =
        text
            .toLowerCase()
            .match(/([a-z']+)[\s,;:]*$/);

    return !!m && DANGLING_WORDS.has(m[1]);
}


/* นับ . ? ! (ไม่นับจุดทศนิยม เช่น 3.14) */

function countTerminators(
    text
) {

    const m =
        text
            .replace(/\d\.\d/g, "")
            .match(/[.?!]/g);

    return m ? m.length : 0;
}


/* ตรวจว่า transcript ขาดเครื่องหมายจบประโยคหรือไม่ */

function detectSparsePunctuation(
    cues
) {

    const info = {

        sparse: false,

        cues: cues.length,

        terminators: 0
    };


    if (
        cues.length < AUTO_PUNCT.minCues
    ) {

        return info;
    }


    for (
        const cue of cues
    ) {

        info.terminators +=
            countTerminators(
                cue.text
            );
    }


    info.sparse =
        (
            info.terminators /
            cues.length
        ) < AUTO_PUNCT.maxTerminatorsPerCue;


    return info;
}


/* เติม . ท้าย cue (แทนที่ , ; : - ที่ค้างอยู่ท้ายข้อความ) */

function addPeriod(
    text
) {

    return (
        text.replace(
            /[\s,;:、，\-–—]+$/,
            ""
        ) + "."
    );
}


/*
    ประมาณความเร็วพูดของคลิปนี้ (ms ต่อตัวอักษร)
    จาก median ของ "ระยะ start→start ของ cue ถัดไป / ความยาวข้อความ"

    ใช้ median เพราะ pause เป็นส่วนน้อย จึงไม่ดึงค่าให้เพี้ยน
    และไม่พึ่ง dur ซึ่งอาจซ้อนทับกันใน raw captions
*/

function estimateMsPerChar(
    cues
) {

    const ratios = [];

    for (
        let i = 0;
        i < cues.length - 1;
        i++
    ) {

        const interval =
            cues[i + 1].start -
            cues[i].start;

        const len =
            cues[i].text.length + 1;

        if (
            interval > 0 &&
            len > 0
        ) {

            ratios.push(
                interval / len
            );
        }
    }


    if (
        !ratios.length
    ) {

        return 70;
    }


    ratios.sort(
        (a, b) => a - b
    );


    const median =
        ratios[
            Math.floor(
                ratios.length / 2
            )
        ];


    return Math.min(
        AUTO_PUNCT.msPerCharMax,
        Math.max(
            AUTO_PUNCT.msPerCharMin,
            median
        )
    );
}


/* dur เป็นเวลาพูดจริงหรือไม่ (ไม่ซ้อนทับ cue ถัดไป) */

function isDurReliable(
    cues
) {

    let ok = 0;

    let total = 0;

    for (
        let i = 0;
        i < cues.length - 1;
        i++
    ) {

        if (
            cues[i].dur == null ||
            cues[i].dur <= 0
        ) {

            continue;
        }

        total++;

        const gap =
            cues[i + 1].start -
            (cues[i].start + cues[i].dur);

        if (
            gap >= -100
        ) {

            ok++;
        }
    }


    return (
        total >= 5 &&
        ok / total >=
            AUTO_PUNCT.reliableDurRatio
    );
}


/*
    เดาตำแหน่งจบประโยค

    หลักการ: ตัดเมื่อ "เงียบนานผิดปกติ" เท่านั้น
    pause ที่ประมาณได้ = ระยะถึง cue ถัดไป − เวลาที่ควรใช้พูดข้อความนี้
    และไม่ตัดถ้า cue ลงท้ายด้วยคำที่ประโยคจบไม่ได้ (and, the, to, ...)
*/

function autoPunctuateCues(
    cues
) {

    const C = AUTO_PUNCT;

    const msPerChar =
        estimateMsPerChar(
            cues
        );

    const durReliable =
        isDurReliable(
            cues
        );

    const T =
        durReliable
            ? C.gap
            : C.estimated;

    const out = [];

    let inserted = 0;

    let groupStart =
        cues[0].start;

    let chars = 0;


    for (
        let i = 0;
        i < cues.length;
        i++
    ) {

        const cue =
            cues[i];

        const next =
            cues[i + 1];

        const text =
            cue.text;


        /* cue นี้มีเครื่องหมายจบอยู่แล้ว → เริ่มกลุ่มใหม่ */

        if (
            /[.?!]$/.test(text)
        ) {

            out.push({ ...cue });

            chars = 0;

            if (next) {

                groupStart =
                    next.start;
            }

            continue;
        }


        chars +=
            text.length + 1;


        /* cue สุดท้าย → ปิดด้วย . เสมอ */

        if (!next) {

            out.push({
                ...cue,
                text: addPeriod(text)
            });

            inserted++;

            break;
        }


        const interval =
            next.start - cue.start;

        const pause =
            durReliable
                ? next.start -
                  (cue.start + (cue.dur || 0))
                : interval -
                  (text.length + 1) * msPerChar;

        const elapsed =
            next.start - groupStart;

        const dangling =
            endsWithDanglingWord(
                text
            );


        let cut = false;


        if (
            !dangling
        ) {

            if (
                chars >= C.minChars &&
                pause >= T.pauseMs
            ) {

                cut = true;

            } else if (
                (
                    chars >= C.softChars ||
                    elapsed >= C.softMs
                ) &&
                pause >= T.softPauseMs
            ) {

                cut = true;

            } else if (
                pause >= T.bigPauseMs
            ) {

                cut = true;
            }
        }


        /* เพดานกันก้อนยักษ์ — ยอมตัดแม้ dangling เมื่อเกิน 1.5 เท่า */

        if (
            !cut &&
            (
                (
                    !dangling &&
                    (
                        chars >= C.hardChars ||
                        elapsed >= C.hardMs
                    )
                ) ||
                chars >= C.hardChars * 1.5 ||
                elapsed >= C.hardMs * 1.5
            )
        ) {

            cut = true;
        }


        if (cut) {

            out.push({
                ...cue,
                text: addPeriod(text)
            });

            inserted++;

            chars = 0;

            groupStart =
                next.start;

        } else {

            out.push({ ...cue });
        }
    }


    return {
        cues: out,
        inserted
    };
}


/* สถานะล่าสุด (ใช้แสดงผลหลังโหลด) */

let lastAutoPunct = {

    applied: false,

    inserted: 0
};


/* ตัวหลัก: ตรวจ → ถ้าขาดเครื่องหมายค่อยเติม */

function applyAutoPunctuation(
    rawSegments
) {

    lastAutoPunct = {

        applied: false,

        inserted: 0
    };


    if (
        !AUTO_PUNCT.enabled
    ) {

        return rawSegments;
    }


    /* ล้าง [...] ก่อน เพื่อตรวจจากข้อความจริง */

    const cues = [];

    for (
        const raw of
        rawSegments
    ) {

        const text =
            cleanTranscriptText(
                raw.text
            );

        if (
            !text
        ) {

            continue;
        }

        cues.push({

            start:
                Math.max(
                    0,
                    Number(raw.start) || 0
                ),

            dur:
                raw.dur == null
                    ? null
                    : Math.max(
                        0,
                        Number(raw.dur) || 0
                    ),

            text
        });
    }


    const info =
        detectSparsePunctuation(
            cues
        );


    if (
        !info.sparse
    ) {

        return rawSegments;
    }


    const fixed =
        autoPunctuateCues(
            cues
        );


    lastAutoPunct = {

        applied: true,

        inserted:
            fixed.inserted
    };


    return fixed.cues;
}


/* =========================================================
   CLEAN + GROUP
========================================================= */

function cleanAndGroupSegments(
    rawSegments
) {

    /*
        ====================================================
        STEP 0
        AUTO PUNCTUATION (เฉพาะเมื่อ transcript ไม่มี . ?)
        ====================================================
    */

    rawSegments =
        applyAutoPunctuation(
            rawSegments
        );


    /*
        ====================================================
        STEP 1
        CLEAN RAW CUES
        ====================================================
    */

    const cleanedRaw = [];


    for (
        const raw of
        rawSegments
    ) {

        const text =
            cleanTranscriptText(
                raw.text
            );


        /*
            If [...]
            was the entire cue,
            it disappears.
        */

        if (
            !text
        ) {

            continue;
        }


        const start =
            Math.max(
                0,
                Number(
                    raw.start
                ) || 0
            );


        let dur =
            raw.dur == null
                ? null
                : Math.max(
                    0,
                    Number(
                        raw.dur
                    ) || 0
                );


        const end =
            dur != null
                ? start + dur
                : start;


        cleanedRaw.push({

            start,

            dur,

            end,

            text
        });
    }


    /*
        ====================================================
        STEP 2
        SPLIT CUES THAT CONTAIN MULTIPLE SENTENCES
        ====================================================
    */

    const expanded = [];


    for (
        let i = 0;
        i < cleanedRaw.length;
        i++
    ) {

        const cue =
            cleanedRaw[i];


        const nextCue =
            cleanedRaw[
                i + 1
            ];


        const pieces =
            splitCueWithEstimatedTiming(
                cue,
                nextCue
                    ? nextCue.start
                    : null
            );


        expanded.push(
            ...pieces
        );
    }


    /*
        ====================================================
        STEP 3
        GROUP INCOMPLETE SENTENCES
        ====================================================
    */

    const groups = [];


    let pending =
        null;


    for (
        const cue of expanded
    ) {

        const text =
            cleanTranscriptText(
                cue.text
            );


        if (
            !text
        ) {

            continue;
        }


        /*
            Start a new pending group.
        */

        if (
            !pending
        ) {

            pending = {

                start:
                    cue.start,

                sourceEnd:
                    cue.end,

                text:
                    text,

                estimated:
                    !!cue.estimated

            };

        } else {

            /*
                Merge the text.

                IMPORTANT:
                We don't sum duration here.

                Duration is calculated AFTER
                sentence grouping using the
                next final group's start.
            */

            pending.text =
                (
                    pending.text +
                    " " +
                    text
                )
                    .replace(
                        /\s+/g,
                        " "
                    )
                    .trim();


            pending.sourceEnd =
                Math.max(
                    pending.sourceEnd,
                    cue.end
                );


            pending.estimated =
                pending.estimated ||
                !!cue.estimated;
        }


        /*
            Once the group reaches a sentence
            ending, close it.
        */

        if (
            endsSentence(
                pending.text
            )
        ) {

            groups.push(
                pending
            );

            pending =
                null;
        }
    }


    /*
        Keep leftover content.

        This can happen if a transcript
        ends without punctuation.
    */

    if (
        pending
    ) {

        groups.push(
            pending
        );
    }


    /*
        ====================================================
        STEP 4
        FINAL SAFETY SPLIT
        ====================================================

        Guarantee:
        each final group contains
        at most one real sentence ending.
    */

    const safeGroups = [];


    for (
        let i = 0;
        i < groups.length;
        i++
    ) {

        const group =
            groups[i];


        const pieces =
            splitIntoSentences(
                group.text
            );


        /*
            Already safe.
        */

        if (
            pieces.length <= 1
        ) {

            safeGroups.push(
                group
            );

            continue;
        }


        /*
            Safety fallback.

            This should be rare because
            Step 2 + Step 3 already split it.
        */

        const nextStart =
            groups[i + 1]
                ?.start ?? null;


        const temporaryCue = {

            start:
                group.start,

            dur:
                Math.max(
                    0,
                    group.sourceEnd -
                    group.start
                ),

            end:
                group.sourceEnd,

            text:
                group.text
        };


        const split =
            splitCueWithEstimatedTiming(
                temporaryCue,
                nextStart
            );


        safeGroups.push(
            ...split.map(
                item => ({

                    start:
                        item.start,

                    sourceEnd:
                        item.end,

                    text:
                        item.text,

                    estimated:
                        true

                })
            )
        );
    }


    /*
        ====================================================
        STEP 5
        CALCULATE FINAL DURATIONS
        ====================================================

        This is important.

        Example:

        00:30.380
        00:33.530

        First duration:

        33.530 - 30.380
        = 3.150 sec

        Exactly what you wanted.
    */

    const finalSegments = [];


    for (
        let i = 0;
        i < safeGroups.length;
        i++
    ) {

        const current =
            safeGroups[i];


        const next =
            safeGroups[
                i + 1
            ];


        let start =
            Math.max(
                0,
                Number(
                    current.start
                ) || 0
            );


        let duration = 0;


        /*
            Prefer next group's start.

            This avoids adding overlapping
            raw cue durations together.
        */

        if (
            next &&
            next.start >
                start
        ) {

            duration =
                next.start -
                start;

        } else {

            /*
                Last group:
                use source end.
            */

            duration =
                Math.max(
                    0,
                    Number(
                        current.sourceEnd
                    ) || 0
                ) -
                start;
        }


        /*
            Fallback for zero duration.
        */

        if (
            duration <= 0
        ) {

            duration =
                2000;
        }


        let text =
            cleanTranscriptText(
                current.text
            );


        /*
            Guarantee no multiple sentence endings.
        */

        const sentencePieces =
            splitIntoSentences(
                text
            );


        if (
            sentencePieces.length > 1
        ) {

            /*
                Emergency recursive normalization.

                We distribute the existing duration.
            */

            const weightList =
                sentencePieces.map(
                    sentenceWeight
                );


            const totalWeight =
                weightList.reduce(
                    (sum, value) =>
                        sum + value,
                    0
                );


            let elapsed = 0;


            sentencePieces.forEach(
                (
                    sentence,
                    pieceIndex
                ) => {

                    const isLast =
                        pieceIndex ===
                        sentencePieces.length - 1;


                    let pieceDuration;


                    if (
                        isLast
                    ) {

                        pieceDuration =
                            duration -
                            elapsed;

                    } else {

                        pieceDuration =
                            Math.round(
                                duration *
                                (
                                    weightList[
                                        pieceIndex
                                    ] /
                                    totalWeight
                                )
                            );
                    }


                    pieceDuration =
                        Math.max(
                            1,
                            pieceDuration
                        );


                    finalSegments.push({

                        start:
                            start +
                            elapsed,

                        dur:
                            pieceDuration,

                        text:
                            sentence,

                        estimated:
                            true
                    });


                    elapsed +=
                        pieceDuration;
                }
            );

        } else {

            finalSegments.push({

                start,

                dur:
                    duration,

                text,

                estimated:
                    !!current.estimated
            });
        }
    }


    /*
        ====================================================
        STEP 6
        FINAL NORMALIZATION
        ====================================================
    */

    const normalized =
        [];


    for (
        let i = 0;
        i < finalSegments.length;
        i++
    ) {

        const item =
            finalSegments[i];


        let text =
            cleanTranscriptText(
                item.text
            );


        if (
            !text
        ) {

            continue;
        }


        /*
            Ensure a sentence cue ends in
            . or ?

            If it ends with !,
            cleanTranscriptText already
            converts it to .
        */

        if (
            !/[?.]$/.test(
                text
            )
        ) {

            /*
                Do NOT add artificial punctuation
                automatically here.

                The only exception is the
                last dangling transcript item
                which is handled below.
            */

            const next =
                finalSegments[
                    i + 1
                ];


            if (
                next
            ) {

                /*
                    It should normally have been
                    merged already, so if this
                    happens it's safer to merge.
                */

                if (
                    normalized.length
                ) {

                    const previous =
                        normalized[
                            normalized.length - 1
                        ];


                    previous.text =
                        (
                            previous.text +
                            " " +
                            text
                        )
                            .replace(
                                /\s+/g,
                                " "
                            )
                            .trim();


                    continue;
                }
            }
        }


        normalized.push({

            start:
                Math.max(
                    0,
                    Number(
                        item.start
                    ) || 0
                ),

            dur:
                Math.max(
                    1,
                    Number(
                        item.dur
                    ) || 1
                ),

            text,

            estimated:
                !!item.estimated
        });
    }


    return normalized;
}


/* =========================================================
   FETCH API
========================================================= */

async function fetchTranscript(
    videoId,
    language = ""
) {

    const params =
        new URLSearchParams();


    params.set(
        "v",
        videoId
    );


    params.set(
        "format",
        "json"
    );


    if (
        language
    ) {

        params.set(
            "lang",
            language
        );
    }


    const endpoint =
        `${API_BASE}?${params.toString()}`;


    const response =
        await netFetch(
            endpoint,
            {
                method:
                    "GET",

                mode:
                    "cors",

                cache:
                    "no-store",

                headers: {

                    Accept:
                        "application/json"
                }
            }
        );


    if (
        !response.ok
    ) {

        let message =
            `HTTP ${response.status}`;


        try {

            const errorData =
                await response.json();


            if (
                errorData?.message
            ) {

                message =
                    errorData.message;
            }

        } catch {}


        throw new Error(
            message
        );
    }


    const data =
        await response.json();


    if (
        !data?.ok
    ) {

        throw new Error(
            data?.message ||
            "Transcript API returned an error"
        );
    }


    if (
        !Array.isArray(
            data.segments
        )
    ) {

        throw new Error(
            "API ไม่ได้ส่ง segments กลับมา"
        );
    }


    return data;
}


/* =========================================================
   ERROR
========================================================= */

function friendlyError(
    error
) {

    const message =
        error?.message ||
        "";


    if (
        message.includes(
            "no_captions"
        )
    ) {

        return (
            "วิดีโอนี้ไม่มี captions"
        );
    }


    if (
        message.includes(
            "login_required"
        )
    ) {

        return (
            "วิดีโอนี้มีข้อจำกัดการเข้าถึง"
        );
    }


    if (
        message.includes(
            "unplayable"
        )
    ) {

        return (
            "วิดีโอนี้ไม่สามารถเข้าถึงได้"
        );
    }


    if (
        message.includes(
            "Failed to fetch"
        )
    ) {

        return (
            "Browser เชื่อมต่อ Transcript API ไม่ได้"
        );
    }


    if (
        message.includes(
            "403"
        )
    ) {

        return (
            "Transcript API ปฏิเสธคำขอ (403)"
        );
    }


    if (
        message.includes(
            "503"
        )
    ) {

        return (
            "Transcript API ชั่วคราวไม่พร้อมใช้งาน"
        );
    }


    return (
        message ||
        "เกิดข้อผิดพลาด"
    );
}



/* =========================================================
   LOAD TRANSCRIPT   (ตรรกะเดิมจาก loadTranscript — ตัดเฉพาะส่วนที่แตะ UI)
========================================================= */

async function loadTranscript(videoId, language = "") {

    if (!videoId) {
        throw new Error("ลิงก์ YouTube ไม่ถูกต้อง");
    }

    currentVideoId = videoId;

    const data = await fetchTranscript( videoId, language );

    currentData = data;

    /*
    Store RAW unchanged.
    */
    currentRawSegments = data.segments.map( segment => ({
        start: Number( segment.start ) || 0,
        dur: segment.dur == null ? null : Number( segment.dur ) || 0,
        text: String( segment.text || "" )
    }) );

    /*
    CLEAN + GROUP
    */
    currentSegments = cleanAndGroupSegments( currentRawSegments );

    /*
    Full text
    */
    currentFullText = currentSegments.map( segment => segment.text ).join(" ");

    currentLanguage = data.track?.language || "";

    /* เดิม renderTranscript() เรียก TTS.reset() เป็นอย่างแรก */
    TTS.reset();

    const estimated = currentSegments.filter( segment => segment.estimated ).length;

    let successMessage =
        `สำเร็จ — ${currentRawSegments.length} raw cues → ${currentSegments.length} sentence cues`;

    if ( estimated > 0 ) {
        successMessage += ` · ${estimated} cues มี timestamp ที่ประมาณจากข้อความ`;
    }

    if ( lastAutoPunct.applied ) {
        successMessage += ` · ไม่พบ . ? ในต้นฉบับ จึงเติม . อัตโนมัติ ${lastAutoPunct.inserted} จุด (เดาจาก pause/ความยาว/เวลา)`;
    }

    return {
        message: successMessage,
        cues: currentSegments.length,
        language: currentLanguage,
        generated: !!data.track?.generated,
        title: data.video?.title || "YouTube Video"
    };
}

/* SRT / TXT (ตรรกะเดิมจากปุ่มดาวน์โหลด — คืนค่าเป็นข้อความ ไม่มี UI) */
function buildSrt() {
    const lines = [];
    currentSegments.forEach( ( segment, index ) => {
        const start = segment.start;
        const next = currentSegments[ index + 1 ];
        let end = start + segment.dur;
        if ( next && next.start > start ) {
            end = next.start;
        }
        if ( end <= start ) {
            end = start + 2000;
        }
        lines.push( String( index + 1 ) );
        lines.push( `${formatSrtTime( start )} --> ${formatSrtTime( end )}` );
        lines.push( segment.text );
        lines.push("");
    } );
    return lines.join("\n");
}

/* =========================================================
   THAI TTS PLAYER  (browser built-in Web Speech API)

   - เล่นตาม timeline แบบ "ยืดหยุ่น": แต่ละ cue เริ่มที่ start และพยายามจบก่อน cue ถัดไป
   - ให้ความสำคัญกับเสียงฟังสบายก่อน: ไม่ตัดเสียงกลางประโยค, เร่งความเร็วได้ไม่เกิน maxRate
   - maxRate ตั้งอัตโนมัติจากการสแกนทุก cue ตอนกด Play (ปิดได้ด้วย maxRateAuto: false)
   - ถ้าพูดไม่ทัน ปล่อยให้พูดจบแล้ว cue ถัดไปเริ่มช้ากว่า timeline ได้ (drift)
   - ถ้า drift เกิน maxLagMs จะข้าม cue ที่ช้าเกินไปเพื่อกลับมาตรง timeline
   - ตัดเสียงเฉพาะกรณี engine ค้างจริง ๆ (hardOverrunMs)
========================================================= */

function createTTS() {

    const CFG = {
        minRate: 1,          // ไม่ช้ากว่าปกติ: ข้อความสั้นก็ปล่อยให้จบก่อนเวลา ไม่ลากเสียง
        maxRate: 1.2,        // เร็วสุดที่ยังฟังสบาย (ค่าสำรอง/ค่าตั้งต้น — ถ้าเปิด auto จะถูกคำนวณใหม่ตอนกด Play)
        maxRateAuto: true,   // true = สแกนคลิปแล้วตั้ง maxRate เอง, false = ใช้ค่า maxRate ด้านบนตายตัว
        maxRateLo: 1.1,      // auto: ต่ำสุดที่จะตั้ง
        maxRateHi: 1.3,      // auto: สูงสุดที่จะตั้ง (กันเสียงเร็วจนฝืน)
        maxRatePct: 0.85,    // auto: เลือก rate ที่ครอบคลุม cue ส่วนใหญ่ (85%) ที่เหลือยอม drift
        defaultCps: 11,      // ตัวอักษร(ถ่วงน้ำหนัก)/วินาที ที่ rate 1 ก่อน calibrate
        fitStart: 0.92,      // เป้าหมายตั้งต้น: พูดให้จบที่ ~92% ของเวลาที่มี (ปรับเองอัตโนมัติ)
        fitMin: 0.80,        // แคบสุดที่ยอมเผื่อ (พูดเลยเวลาบ่อย → เผื่อเพิ่มถึงตรงนี้)
        fitMax: 0.97,        // กว้างสุด (จบทันสบาย → ค่อย ๆ ลดการเผื่อลงได้ถึงตรงนี้)
        maxLagMs: 6000,      // cue ที่เริ่มช้ากว่า start เกินนี้ → ข้ามเพื่อกลับมาตรง timeline
        hardOverrunMs: 8000, // engine ค้างเกินเวลานี้หลัง deadline → ค่อยตัดจริง
        tailMs: 80,          // เผื่อ onend lag
        skipTailMs: 150,     // cue ที่เหลือเวลาน้อยกว่านี้จะข้าม
        partialMinRatio: 0.25, // seek กลางคิว: เหลือน้อยกว่านี้ไม่พูด
        seekLeadMs: 300,     // คลิก cue แล้วถอยหลังนิดหน่อยให้เริ่มตรง start
        tickMs: 20
    };

    const synth = window.speechSynthesis;
    const supported =
        !!synth && "SpeechSynthesisUtterance" in window;

    const el = makeHeadlessEl();

    const S = {
        playing: false,
        busy: false,
        dragging: false,
        pos: 0,            // ตำแหน่ง timeline (ms) ตอนที่ t0
        t0: 0,
        nextIdx: 0,
        fresh: true,       // เพิ่ง play/seek: cue แรกอาจอยู่กลางคิว (ตัดข้อความที่ผ่านไปแล้ว)
        activeIdx: -1,
        cur: null,
        total: 0,
        voice: null,
        source: "th",      // "th" = อ่านคำแปล, "orig" = อ่านต้นฉบับ
        cal: null,         // { cps, gamma }
        fit: 0.80,         // สัดส่วนเวลาที่ตั้งใจใช้พูด (ปรับอัตโนมัติ)
        recent: [],        // ตัวอย่างความเร็วเสียงล่าสุด (ใช้วางแผนแบบระวังไว้ก่อน)
        latency: 150,      // ms จาก speak() ถึง onstart
        worker: null,
        workerUrl: "",
        timer: 0,
        lastUi: 0,
        vol: 1,            // (extension) ระดับเสียงพากย์ 0..1
        clock: 1           // (extension) ความเร็ววิดีโอ: timeline ms ต่อ 1 ms จริง
    };

    /* ---------------------------------------------------------
       helpers
    --------------------------------------------------------- */

    const segs = () => currentSegments;

    const speechText = c =>
        (S.source === "th" && c.th) ? c.th : c.text;

    const normLang = l =>
        String(l || "").replace(/^a\./i, "").split(/[-_]/)[0].toLowerCase();

    const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

    const now = () => performance.now();

    const getPos = () =>
        S.playing ? S.pos + (now() - S.t0) * S.clock : S.pos;

    function fmt(ms) {
        const s = Math.max(0, Math.floor(ms / 1000));
        const h = Math.floor(s / 3600);
        const m = Math.floor((s % 3600) / 60);
        const ss = s % 60;
        const p = n => String(n).padStart(2, "0");
        return h ? `${h}:${p(m)}:${p(ss)}` : `${p(m)}:${p(ss)}`;
    }

    function setInfo(text, warn) {
        el.info.textContent = text || "";
        el.info.classList.toggle("warn", !!warn);
    }

    function segInfo(i, text, cls) {
        emit("segInfo", { i, text, cls });
    }

    /* น้ำหนักข้อความ ≈ เวลาที่ต้องใช้พูด (สระ/วรรณยุกต์ไม่นับ, ตัวเลขอ่านยาว, วรรคตอนมี pause) */
    function rawWeight(text) {
        let w = 0;
        for (const ch of text) {
            if (/[\u0E31\u0E34-\u0E3A\u0E47-\u0E4E]/.test(ch)) continue;
            if (/\s/.test(ch)) w += 0.4;
            else if (/\p{Nd}/u.test(ch)) w += 2;
            else if (/[,;:，、]/.test(ch)) w += 1;
            else if (/[.!?…。！？]/.test(ch)) w += 1.5;
            else if (/\p{L}/u.test(ch)) w += 1;
            else w += 0.2;
        }
        return w;
    }

    const weightOf = text => Math.max(0.5, rawWeight(text));

    /* ตัดข้อความตั้งแต่สัดส่วน f (ใช้ตอน seek เข้ากลาง cue) ให้ตรงขอบคำ */
    function sliceFromFraction(text, f) {
        const total = rawWeight(text);
        const target = total * f;
        let acc = 0, idx = 0;
        const chars = Array.from(text);
        let offset = 0;
        for (let k = 0; k < chars.length; k++) {
            acc += rawWeight(chars[k]);
            offset += chars[k].length;
            if (acc >= target) { idx = offset; break; }
        }
        if (typeof Intl !== "undefined" && Intl.Segmenter) {
            try {
                const seg = new Intl.Segmenter("th", { granularity: "word" });
                for (const part of seg.segment(text)) {
                    if (part.index >= idx) { idx = part.index; break; }
                }
            } catch (e) { /* ignore */ }
        }
        return text.slice(idx).trim();
    }

    /* เวลาที่ต้องพูด (ms) ที่ rate r */
    const speakMs = (w, r) =>
        (w / S.cal.cps) * 1000 / Math.pow(r, S.cal.gamma);

    /* rate ที่ทำให้พูดจบใน targetMs */
    function plannedCps() {
        // วางแผนด้วยความเร็วเสียงเฉลี่ยล่าสุด (ไม่ใช้ค่าแย่สุด จะได้ไม่เร่งเกินจำเป็น)
        const r = S.recent.slice(-6);
        if (r.length < 2) return S.cal.cps * 0.95;
        const avg = r.reduce((a, b) => a + b, 0) / r.length;
        return Math.min(S.cal.cps, avg);
    }

    function pushSample(cps1) {
        if (!(cps1 > 0)) return;
        S.recent.push(clamp(cps1, 3, 40));
        if (S.recent.length > 12) S.recent.shift();
    }

    function rateFor(w, targetMs) {
        const base = (w / plannedCps()) * 1000;
        const r = Math.pow(base / targetMs, 1 / S.cal.gamma);
        return r;
    }

    function indexAt(pos) {
        const list = segs();
        let lo = 0, hi = list.length - 1, ans = -1;
        while (lo <= hi) {
            const mid = (lo + hi) >> 1;
            if (list[mid].start <= pos) { ans = mid; lo = mid + 1; }
            else hi = mid - 1;
        }
        return ans;
    }

    /* เวลาที่ cue นี้ควรพูดให้จบ: ใช้ช่องว่างจนถึง cue ถัดไปได้ (ไม่ใช่แค่ start+dur) */
    function softDeadline(i) {
        const list = segs();
        const c = list[i];
        const own = c.start + c.dur;
        const next = list[i + 1];
        return next && next.start > own ? next.start : own;
    }

    function firstIdxAfter(pos) {
        const list = segs();
        for (let i = 0; i < list.length; i++) {
            if (list[i].start + list[i].dur - CFG.skipTailMs > pos) return i;
        }
        return list.length;
    }

    /* ---------------------------------------------------------
       voices
    --------------------------------------------------------- */

    function loadVoices() {
        if (!supported) return;
        const all = synth.getVoices();
        const th = all.filter(v => /^th/i.test(v.lang));
        const list = (th.length ? th : all).slice().sort((a, b) =>
            (b.localService - a.localService) ||
            a.name.localeCompare(b.name)
        );

        let saved = "";
        try { saved = store.getItem("tts-voice") || ""; } catch (e) { }
        const keep = S.voice ? S.voice.voiceURI : saved;

        el.voice.innerHTML = "";
        list.forEach(v => {
            const o = document.createElement("option");
            o.value = v.voiceURI;
            o.textContent =
                `${v.name} (${v.lang})${v.localService ? "" : " · online"}`;
            el.voice.appendChild(o);
        });

        const chosen =
            list.find(v => v.voiceURI === keep) || list[0] || null;

        if (chosen) {
            el.voice.value = chosen.voiceURI;
            setVoice(chosen);
        }

        if (!th.length && all.length) {
            setInfo(
                "ไม่พบเสียงภาษาไทยในระบบ — ติดตั้ง Thai voice (เช่น Microsoft Premwadee / Narisa / Kanya) แล้วรีเฟรช",
                true
            );
        }
    }

    function setVoice(v) {
        S.voice = v;
        S.cal = null;
        S.recent = [];
        S.fit = CFG.fitStart;
        try {
            const raw = store.getItem("tts-cal:" + v.voiceURI);
            if (raw) {
                const c = JSON.parse(raw);
                if (c && c.cps > 0 && c.gamma > 0) S.cal = c;
            }
        } catch (e) { }
    }

    function saveCal() {
        if (!S.voice || !S.cal) return;
        try {
            store.setItem(
                "tts-cal:" + S.voice.voiceURI,
                JSON.stringify(S.cal)
            );
        } catch (e) { }
    }

    /* ---------------------------------------------------------
       calibration: วัดความเร็วจริงของ voice ที่ rate 1 และ 2
       (เล่นด้วย volume เกือบ 0)
    --------------------------------------------------------- */

    function measure(text, rate) {
        return new Promise(resolve => {
            const u = new SpeechSynthesisUtterance(text);
            u.voice = S.voice;
            u.lang = S.voice.lang || "th-TH";
            u.rate = rate;
            u.volume = 0.01;
            let t = 0, done = false;
            const finish = v => {
                if (done) return;
                done = true;
                clearTimeout(guard);
                resolve(v);
            };
            const guard = setTimeout(() => finish(null), 12000);
            u.onstart = () => { t = now(); };
            u.onend = () => finish(t ? now() - t : null);
            u.onerror = () => finish(null);
            window.__ttsCalUtt = u; // กัน GC
            synth.speak(u);
        });
    }

    /* สแกนทุก cue ของคลิป แล้วตั้ง maxRate ให้พอดีกับจังหวะของคลิปนี้
       - คำนวณ rate ที่แต่ละ cue "ต้องการ" (เหมือนที่ startCue ใช้)
       - เลือกค่าที่ครอบคลุม cue ส่วนใหญ่ แล้วบีบให้อยู่ใน [maxRateLo, maxRateHi] */
    function autoTuneMaxRate() {
        if (!CFG.maxRateAuto || !S.cal) return null;
        const list = segs();
        const cps = S.cal.cps * 0.95;
        const rates = [];
        for (let i = 0; i < list.length; i++) {
            const c = list[i];
            const text = speechText(c);
            if (!text) continue;
            const avail = softDeadline(i) - c.start;
            const target = Math.max(250, avail * CFG.fitStart / S.clock - CFG.tailMs);
            const base = (weightOf(text) / cps) * 1000;
            rates.push(Math.pow(base / target, 1 / S.cal.gamma));
        }
        if (rates.length < 3) return null;
        rates.sort((a, b) => a - b);
        const q = rates[Math.min(rates.length - 1, Math.floor(rates.length * CFG.maxRatePct))];
        CFG.maxRate = Math.round(clamp(q, CFG.maxRateLo, CFG.maxRateHi) * 20) / 20;
        return CFG.maxRate;
    }

    async function ensureCalibration() {
        if (S.cal) return;

        const A = "สวัสดีครับ วันนี้เรามาเริ่มกันเลย";
        const B = "ขอบคุณที่ติดตามนะครับ แล้วพบกันใหม่";
        const wA = weightOf(A), wB = weightOf(B);

        synth.cancel();
        const a1 = await measure(A, 1);
        const a2 = await measure(A, 2);
        const b1 = await measure(B, 1);

        const ok = v => v && v > 250;
        let cps = CFG.defaultCps, gamma = 0.9;

        if (ok(a1) && ok(b1)) {
            cps = ((wA / (a1 / 1000)) + (wB / (b1 / 1000))) / 2;
        } else if (ok(a1)) {
            cps = wA / (a1 / 1000);
        }
        if (ok(a1) && ok(a2)) {
            gamma = clamp(Math.log(a1 / a2) / Math.log(2), 0.3, 1.1);
        }

        S.cal = { cps: clamp(cps, 3, 40), gamma };
        saveCal();
    }

    /* ---------------------------------------------------------
       speaking a cue
    --------------------------------------------------------- */

    function startCue(i, pos) {
        const c = segs()[i];
        const cueEnd = softDeadline(i);

        if (S.cur) cutCurrent();

        let text = speechText(c);
        let partial = false;

        const fresh = S.fresh;
        S.fresh = false;

        const elapsed = pos - c.start;
        if (fresh) {
            // เพิ่งกด play/seek: อาจเริ่มกลางคิว → พูดเฉพาะส่วนที่เหลือ
            if (elapsed > 250) {
                const f = elapsed / c.dur;
                if (f > 1 - CFG.partialMinRatio) {
                    segInfo(i, "ข้าม (เหลือเวลาน้อย)", "cut");
                    return;
                }
                text = sliceFromFraction(text, f);
                partial = true;
                if (!text) return;
            }
        } else if (elapsed > CFG.maxLagMs) {
            // เล่นต่อเนื่องแต่ช้าสะสมเกินไป → ข้าม cue นี้เพื่อกลับมาตรง timeline
            segInfo(i, `ข้าม (ช้ากว่า timeline ${(elapsed / 1000).toFixed(1)}s)`, "cut");
            return;
        }

        const speechStart = Math.max(c.start, pos + S.latency * S.clock);
        const avail = cueEnd - speechStart;
        const target = Math.max(250, avail * S.fit / S.clock - CFG.tailMs);

        const w = weightOf(text);
        const need = rateFor(w, target);
        const rate = clamp(need, CFG.minRate, CFG.maxRate);

        const u = new SpeechSynthesisUtterance(text);
        u.voice = S.voice;
        u.lang = S.voice.lang || "th-TH";
        u.rate = rate;
        u.pitch = 1;
        u.volume = S.vol;

        const cur = {
            i, u, text, w, rate, partial,
            deadline: cueEnd,
            avail,
            floored: need < CFG.minRate,
            callPos: pos,
            startPos: null,
            bounds: []
        };

        u.onstart = () => {
            if (S.cur !== cur) return;
            cur.startPos = getPos();
            const lat = clamp((cur.startPos - cur.callPos) / S.clock, 0, 800);
            S.latency = S.latency * 0.7 + lat * 0.3;
        };

        u.onboundary = e => {
            if (S.cur !== cur || cur.startPos == null) return;
            if (e.charIndex > 0) {
                cur.bounds.push({ char: e.charIndex, t: getPos() });
            }
        };

        u.onend = () => {
            if (S.cur !== cur) return;
            S.cur = null;
            const spoken =
                cur.startPos == null ? 0 : (getPos() - cur.startPos) / S.clock;
            const lateStart =
                cur.startPos == null ? 0 : cur.startPos - c.start;

            if (!cur.partial && spoken > 250) {
                const cps1 =
                    cur.w / ((spoken / 1000) * Math.pow(cur.rate, S.cal.gamma));
                S.cal.cps = clamp(S.cal.cps * 0.6 + cps1 * 0.4, 3, 40);
                pushSample(cps1);
            }

            // เหลือเวลาก่อนหมด cue เท่าไร → ปรับระยะเผื่อ
            const leftMs = cur.deadline - getPos();
            if (cur.startPos != null && cur.avail > 0) {
                if (leftMs < 0) {
                    S.fit = Math.max(CFG.fitMin, S.fit - 0.03);
                } else if (!cur.floored && leftMs > cur.avail * 0.30) {
                    S.fit = Math.min(CFG.fitMax, S.fit + 0.01);
                }
            }

            const over = need > CFG.maxRate + 0.01;
            segInfo(
                i,
                `TTS ${(spoken / 1000).toFixed(2)}s / ${(c.dur / 1000).toFixed(2)}s · ×${cur.rate.toFixed(2)}` +
                (leftMs < 0
                    ? ` · เลยเวลา ${(-leftMs / 1000).toFixed(2)}s`
                    : ` · เหลือ ${(leftMs / 1000).toFixed(2)}s`) +
                (Math.abs(lateStart) > 80 ? ` · เริ่ม ${lateStart > 0 ? "+" : ""}${Math.round(lateStart)}ms` : "") +
                (over ? " · เกินเพดานความเร็ว" : ""),
                over ? "cut" : "ok"
            );
        };

        u.onerror = e => {
            if (S.cur !== cur) return;
            const err = e && e.error;
            if (err === "interrupted" || err === "canceled") return;
            S.cur = null;
            setInfo("TTS error: " + (err || "unknown"), true);
        };

        S.cur = cur;
        synth.speak(u);

        setInfo(
            `cue ${i + 1}/${segs().length} · speed ×${rate.toFixed(2)} · เผื่อเวลา ${Math.round((1 - S.fit) * 100)}%` +
            (need > CFG.maxRate + 0.01
                ? ` (ต้องการ ×${need.toFixed(2)} เกินเพดาน ×${CFG.maxRate} — จะพูดเลยเวลา/ช้ากว่า timeline เล็กน้อย)`
                : ""),
            need > CFG.maxRate + 0.01
        );
    }

    /* ตัด utterance ปัจจุบันทิ้ง + เรียนรู้ว่า "ช้าไป" */
    function cutCurrent() {
        const cur = S.cur;
        if (!cur) return;
        S.cur = null;
        synth.cancel();

        const c = segs()[cur.i];

        if (cur.startPos == null) {
            // engine ยังไม่ทันเริ่มพูด → latency จริงสูงกว่าที่คิด
            S.latency = Math.min(800, S.latency + 80);
            segInfo(cur.i, "ไม่ทันเริ่ม (latency สูง)", "cut");
            return;
        }

        const last = cur.bounds[cur.bounds.length - 1];
        let needed = null;
        if (last) {
            const frac = rawWeight(cur.text.slice(0, last.char)) / cur.w;
            if (frac > 0.1) needed = ((last.t - cur.startPos) / S.clock) / frac;
        }
        if (needed && !cur.partial) {
            const cps1 =
                cur.w / ((needed / 1000) * Math.pow(cur.rate, S.cal.gamma));
            S.cal.cps = clamp(S.cal.cps * 0.6 + cps1 * 0.4, 3, 40);
            pushSample(cps1);
        } else if (!cur.partial) {
            S.cal.cps = clamp(S.cal.cps * 0.85, 3, 40);
            pushSample(S.cal.cps * 0.85);
        }
        S.fit = Math.max(CFG.fitMin, S.fit - 0.04);

        segInfo(
            cur.i,
            `ถูกตัด (engine ค้างเกิน ${(CFG.hardOverrunMs / 1000).toFixed(0)}s) · ×${cur.rate.toFixed(2)}`,
            "cut"
        );
    }

    /* ---------------------------------------------------------
       clock
    --------------------------------------------------------- */

    function tick() {
        if (!S.playing) return;
        const list = segs();
        const pos = getPos();

        // ไม่ตัดเสียงตอนถึง deadline อีกต่อไป — ตัดเฉพาะกรณี engine ค้างจริง ๆ
        if (S.cur && pos >= S.cur.deadline + CFG.hardOverrunMs) cutCurrent();

        while (S.nextIdx < list.length) {
            const c = list[S.nextIdx];
            if (pos + S.latency * S.clock < c.start) break;
            if (S.cur) break; // รอ cue ก่อนหน้าพูดจบเอง (ไม่ตัดกลางประโยค)
            const i = S.nextIdx++;
            if (S.fresh && pos >= c.start + c.dur - CFG.skipTailMs) continue;
            startCue(i, pos);
            break;
        }

        const ai = indexAt(pos);
        if (ai !== S.activeIdx && ai >= 0) {
            S.activeIdx = ai;
            highlightSegment(ai);
        }

        paintUi(pos);

        if (pos >= S.total && !S.cur && S.nextIdx >= list.length) {
            finish();
        }
    }

    function startTicker() {
        stopTicker();
        try {
            const blob = new Blob(
                [`setInterval(()=>postMessage(1),${CFG.tickMs})`],
                { type: "text/javascript" }
            );
            S.workerUrl = URL.createObjectURL(blob);
            S.worker = new Worker(S.workerUrl);
            S.worker.onmessage = tick;
            S.worker.onerror = () => {
                if (S.worker) { S.worker.terminate(); S.worker = null; }
                if (S.workerUrl) { URL.revokeObjectURL(S.workerUrl); S.workerUrl = ""; }
                if (!S.timer && S.playing) S.timer = setInterval(tick, CFG.tickMs);
            };
        } catch (e) {
            S.timer = setInterval(tick, CFG.tickMs);
        }
    }

    function stopTicker() {
        if (S.worker) { S.worker.terminate(); S.worker = null; }
        if (S.workerUrl) { URL.revokeObjectURL(S.workerUrl); S.workerUrl = ""; }
        if (S.timer) { clearInterval(S.timer); S.timer = 0; }
    }

    function paintUi(pos, force) {
        const t = now();
        if (!force && t - S.lastUi < 80) return;
        S.lastUi = t;
        const p = clamp(pos, 0, S.total);
        if (!S.dragging) el.seek.value = String(p);
        el.time.textContent = `${fmt(p)} / ${fmt(S.total)}`;
    }

    function paintButton() {
        el.play.disabled = S.busy;
        el.play.textContent = S.busy
            ? "กำลังปรับเสียง…"
            : S.playing ? "⏸ Pause" : "▶ Play";
    }

    /* ---------------------------------------------------------
       transport
    --------------------------------------------------------- */

    async function play() {
        if (!supported || !segs().length || S.busy) return;
        if (!S.voice) {
            setInfo("ไม่พบ voice สำหรับอ่านออกเสียง", true);
            return;
        }

        if (S.playing) { pause(); return; }

        if (
            S.source === "th" &&
            normLang(currentLanguage) !== "th" &&
            !segs().some(c => c.th)
        ) {
            setInfo("ต้นฉบับไม่ใช่ภาษาไทย — กด “แปลเป็นไทย” ก่อน หรือเลือก “อ่านต้นฉบับ”", true);
            return;
        }

        if (S.pos >= S.total - 100) S.pos = 0;

        if (!S.cal) {
            S.busy = true;
            paintButton();
            setInfo("กำลังวัดความเร็วเสียงของ voice นี้ (ครั้งเดียว ~5 วินาที)…");
            await ensureCalibration();
            S.busy = false;
        }

        const autoRate = autoTuneMaxRate();

        S.t0 = now();
        S.playing = true;
        S.nextIdx = firstIdxAfter(S.pos);
        S.fresh = true;
        S.activeIdx = -1;
        startTicker();
        paintButton();
        setInfo(
            autoRate
                ? `กำลังเล่น… (maxRate อัตโนมัติ ×${autoRate.toFixed(2)})`
                : "กำลังเล่น…"
        );
    }

    function pause() {
        if (!S.playing) return;
        S.pos = getPos();
        S.playing = false;
        stopTicker();
        S.cur = null;
        synth.cancel();
        saveCal();
        paintButton();
        paintUi(S.pos, true);
        setInfo("หยุดชั่วคราว");
    }

    function finish() {
        S.playing = false;
        stopTicker();
        S.pos = S.total;
        S.cur = null;
        synth.cancel();
        saveCal();
        paintButton();
        paintUi(S.total, true);
        setInfo("เล่นจบแล้ว");
    }

    function seek(ms) {
        const p = clamp(ms, 0, S.total);
        S.cur = null;
        synth.cancel();
        S.pos = p;
        S.t0 = now();
        S.nextIdx = firstIdxAfter(p);
        S.fresh = true;
        const ai = indexAt(p);
        if (ai >= 0) {
            S.activeIdx = ai;
            highlightSegment(ai);
        }
        paintUi(p, true);
    }

    function seekToIndex(i) {
        const c = segs()[i];
        if (!c) return;
        highlightSegment(i);
        S.activeIdx = i;
        seek(c.start - CFG.seekLeadMs);
        if (!S.playing) play();
    }

    function stop() {
        if (S.playing) pause();
        seek(0);
        setInfo("");
    }

    function reset() {
        if (TR.running) TR.abort = true;
        if (S.playing) {
            S.playing = false;
            stopTicker();
        }
        S.cur = null;
        if (supported) synth.cancel();
        S.busy = false;
        S.fit = CFG.fitStart;
        S.recent = [];
        S.pos = 0;
        S.nextIdx = 0;
        S.fresh = true;
        S.activeIdx = -1;
        const list = segs();
        S.total = list.reduce(
            (m, c) => Math.max(m, c.start + c.dur), 0
        );
        el.seek.max = String(S.total);
        el.seek.value = "0";
        el.bar.classList.toggle("show", supported && list.length > 0);
        paintTransBtn();
        paintButton();
        paintUi(0, true);
        setInfo(
            supported
                ? "กด Play เพื่อให้เสียงอ่านตาม timeline — คลิกแถวใดก็ได้เพื่อกระโดดไปเล่นจากจุดนั้น"
                : "เบราว์เซอร์นี้ไม่รองรับ speechSynthesis",
            !supported
        );
    }


    /* ---------------------------------------------------------
       translation → Thai (per cue)
       1) Chrome built-in Translator API (on-device) ถ้ามี
       2) fallback: Google Translate endpoint (gtx)
    --------------------------------------------------------- */

    const TR = { running: false, abort: false };

    async function nativeTranslator(sl) {
        try {
            if (!sl || !("Translator" in self)) return null;
            const opts = { sourceLanguage: sl, targetLanguage: "th" };
            const av = await Translator.availability(opts);
            if (av === "unavailable") return null;
            return await Translator.create({
                ...opts,
                monitor(m) {
                    m.addEventListener("downloadprogress", e =>
                        setInfo(`กำลังดาวน์โหลดโมเดลแปลภาษา ${Math.round(e.loaded * 100)}%…`)
                    );
                }
            });
        } catch (e) {
            return null;
        }
    }

    async function googleTranslate(text, sl) {
        const url =
            "https://translate.googleapis.com/translate_a/single?client=gtx" +
            `&sl=${encodeURIComponent(sl || "auto")}&tl=th&dt=t&q=${encodeURIComponent(text)}`;
        const r = await netFetch(url);
        if (!r.ok) throw new Error("HTTP " + r.status);
        const j = await r.json();
        return (j[0] || []).map(x => x[0] || "").join("");
    }

    async function withRetry(fn, tries = 3) {
        let err;
        for (let k = 0; k < tries; k++) {
            try { return await fn(); }
            catch (e) { err = e; await new Promise(r => setTimeout(r, 400 * (k + 1))); }
        }
        throw err;
    }

    function showTh(list, i) {
        if (segs() !== list) return;
        emit("translated", { i });
    }

    function paintTransBtn() {
        const list = segs();
        const isTh = normLang(currentLanguage) === "th";
        el.trans.style.display = isTh ? "none" : "";
        el.source.style.display = isTh ? "none" : "";
        if (TR.running) el.trans.textContent = "⏹ หยุดแปล";
        else if (list.length && list.every(c => c.th)) el.trans.textContent = "🌐 แปลแล้ว ✓";
        else el.trans.textContent = "🌐 แปลเป็นไทย";
    }

    async function translateAll(startFrom = 0) {
        if (TR.running) { TR.abort = true; return; }

        const list = segs();
        if (!list.length) return;

        const sl = normLang(currentLanguage);
        if (sl === "th") {
            setInfo("ต้นฉบับเป็นภาษาไทยอยู่แล้ว ไม่ต้องแปล");
            return;
        }

        const todo = list.map((c, i) => i).filter(i => !list[i].th);
        if (startFrom > 0) {
            const k = todo.findIndex(i => i >= startFrom);
            if (k > 0) todo.push(...todo.splice(0, k));
        }
        if (!todo.length) { paintTransBtn(); return; }

        TR.running = true;
        TR.abort = false;
        paintTransBtn();
        setInfo("กำลังเตรียมตัวแปลภาษา…");

        const native = await nativeTranslator(sl);
        const total = todo.length;
        const cache = new Map();
        let done = 0, failed = 0;

        const one = async text => {
            if (cache.has(text)) return cache.get(text);
            let out = null;
            if (native) {
                try { out = await native.translate(text); } catch (e) { out = null; }
            }
            if (out == null) out = await withRetry(() => googleTranslate(text, sl));
            cache.set(text, out);
            return out;
        };

        const worker = async () => {
            while (!TR.abort && segs() === list) {
                const i = todo.shift();
                if (i === undefined) break;
                try {
                    const th = (await one(list[i].text) || "").trim();
                    if (th) { list[i].th = th; showTh(list, i); } else failed++;
                } catch (e) {
                    failed++;
                }
                done++;
                setInfo(`กำลังแปล ${done}/${total}${native ? " (on-device)" : ""}…`);
            }
        };

        await Promise.all(Array.from({ length: native ? 1 : 4 }, worker));

        const aborted = TR.abort || segs() !== list;
        TR.running = false;
        TR.abort = false;
        if (segs() === list) paintTransBtn();

        if (aborted) { setInfo("หยุดแปลแล้ว"); return; }

        const ok = list.filter(c => c.th).length;
        if (!ok) {
            setInfo("แปลไม่สำเร็จ — ตรวจสอบอินเทอร์เน็ต หรือลองใหม่อีกครั้ง", true);
            return;
        }
        S.source = "th";
        el.source.value = "th";
        setInfo(
            `แปลเสร็จ ${ok}/${list.length} cue` +
            (failed ? ` (ล้มเหลว ${failed} cue — จะอ่านต้นฉบับแทน)` : "") +
            " · กด Play เพื่อฟังเสียงไทย"
        );
    }

    /* ---------------------------------------------------------
       events
    --------------------------------------------------------- */

    el.play.addEventListener("click", play);
    el.trans.addEventListener("click", translateAll);
    el.source.addEventListener("change", () => { S.source = el.source.value; });
    el.stop.addEventListener("click", stop);

    el.seek.addEventListener("input", () => {
        S.dragging = true;
        el.time.textContent =
            `${fmt(+el.seek.value)} / ${fmt(S.total)}`;
    });

    el.seek.addEventListener("change", () => {
        S.dragging = false;
        seek(+el.seek.value);
    });

    el.voice.addEventListener("change", () => {
        const v = synth.getVoices().find(x => x.voiceURI === el.voice.value);
        if (!v) return;
        if (S.playing) pause();
        setVoice(v);
        try { store.setItem("tts-voice", v.voiceURI); } catch (e) { }
    });

    if (supported) {
        synth.addEventListener("voiceschanged", loadVoices);
        loadVoices();
        window.addEventListener("pagehide", () => synth.cancel());
    }

    /* ---- เพิ่มเติมสำหรับ extension (ไม่แตะ logic เดิม) ---- */
    function selectVoice(uri) {
        if (!supported) return false;
        const v = synth.getVoices().find(x => x.voiceURI === uri);
        if (!v) return false;
        if (S.voice && S.voice.voiceURI === uri) return true;
        if (S.playing) pause();
        setVoice(v);
        try { store.setItem("tts-voice", v.voiceURI); } catch (e) { }
        return true;
    }
    function setClock(r) {
        r = clamp(Number(r) || 1, 0.25, 4);
        if (r === S.clock) return;
        if (S.playing) { S.pos = getPos(); S.t0 = now(); }   // ตรึงตำแหน่งก่อนเปลี่ยนความเร็ว
        S.clock = r;
    }
    function setVolume(v) { S.vol = clamp(Number(v) || 0, 0, 1); }
    async function prepare() {
        if (!supported || !S.voice) return false;
        if (!S.cal) await ensureCalibration();
        return !!S.cal;
    }
    return {
        reset, seekToIndex, play, pause, stop, seek, translateAll,
        selectVoice, setVolume, setClock, prepare, supported,
        getPos, isPlaying: () => S.playing, isBusy: () => S.busy,
        isTranslating: () => TR.running, abortTranslate: () => { if (TR.running) TR.abort = true; },
        hasVoice: () => !!S.voice, voiceURI: () => (S.voice ? S.voice.voiceURI : ""),
        total: () => S.total, indexAt
    };
}


/* ---------- public API ---------- */
let TTS = null;

async function init() {
    if (TTS) return api;
    await hydrateStore();
    TTS = createTTS();
    /* เสียง/ค่าที่เปลี่ยนจาก side panel มีผลทันที */
    try {
        chrome.storage.onChanged.addListener((changes, area) => {
            if (area !== "local") return;
            for (const key of Object.keys(changes)) {
                if (!key.startsWith(STORE_PREFIX)) continue;
                const k = key.slice(STORE_PREFIX.length);
                const nv = changes[key].newValue;
                if (nv == null) delete storeCache[k]; else storeCache[k] = String(nv);
                if (k === "tts-voice" && nv) TTS.selectVoice(String(nv));
            }
        });
    } catch (e) { }
    return api;
}

const api = {
    init, on,
    loadTranscript, buildSrt, getVideoId, friendlyError, formatTime,
    getSegments: () => currentSegments,
    getLanguage: () => currentLanguage,
    getFullText: () => currentFullText,
    getVideoIdLoaded: () => currentVideoId,
    get tts() { return TTS; }
};
window.PakyDubbing = api;

})();
