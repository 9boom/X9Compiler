// คลิกไอคอน extension -> เปิด/ปิด Side Panel
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);
});
chrome.runtime.onStartup.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(console.error);
});

// ---------------------------------------------------------------
// Network proxy ให้ content script (เลี่ยง CORS/CSP ของ youtube.com)
// อนุญาตเฉพาะ GET ไปยังโดเมนที่ dubbing.js ใช้เท่านั้น
// ---------------------------------------------------------------
const PAKY_FETCH_ALLOW = ['youtubegpt.ai', 'translate.googleapis.com'];

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'paky:fetch') return false;
  (async () => {
    try {
      if (sender.id !== chrome.runtime.id) throw new Error('forbidden sender');
      const u = new URL(msg.url);
      if (u.protocol !== 'https:' || !PAKY_FETCH_ALLOW.includes(u.hostname)) throw new Error('blocked host');
      const init = msg.init || {};
      const r = await fetch(u.href, {
        method: 'GET',
        headers: init.headers || undefined,
        cache: init.cache || undefined
      });
      sendResponse({ ok: r.ok, status: r.status, text: await r.text() });
    } catch (e) {
      sendResponse({ error: String((e && e.message) || e) });
    }
  })();
  return true; // async response
});
