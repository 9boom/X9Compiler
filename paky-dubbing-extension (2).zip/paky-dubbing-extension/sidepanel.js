/* PAKY Dubbing – side panel logic (UI เท่านั้น ยังไม่ต่อ backend) */
(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const popup = $('popup');

  /* ------------------------------------------------------------------
     Scale: ดีไซน์กว้าง 314px -> ขยายให้เต็มความกว้าง side panel
     (ผู้ใช้ลากปรับความกว้าง panel ได้ ตัวอักษรจะใหญ่ตามอัตโนมัติ)
     ------------------------------------------------------------------ */
  const DESIGN_W = 314;
  const MIN_SCALE = 1, MAX_SCALE = 2.4;
  function applyScale() {
    const z = Math.max(MIN_SCALE, Math.min(MAX_SCALE, window.innerWidth / DESIGN_W));
    document.body.style.zoom = z;
  }
  applyScale();
  window.addEventListener('resize', applyScale);

  /* ------------------------------------------------------------------
     ข้อมูลตัวเลือก dropdown – เพิ่มได้ที่นี่
     ------------------------------------------------------------------ */
  const FROM_LANGS = [{ value: 'en', label: 'english' }];
  const TO_LANGS   = [{ value: 'th', label: 'ไทย' }];
  const VOICES     = [{ value: '', label: 'กำลังโหลดเสียง…' }];   // เติมจากเสียงที่ติดตั้งในเครื่องผู้ใช้ (ดูด้านล่าง)

  /* ค่าที่ใช้ร่วมกับ content script (chrome.storage.local) */
  const KEY_VOICE = 'paky:tts-voice', KEY_VIDEO = 'paky:vol-video', KEY_DUB = 'paky:vol-dub';
  const store = {
    get: (keys) => (chrome.storage ? chrome.storage.local.get(keys) : Promise.resolve({})),
    set: (obj) => { try { chrome.storage.local.set(obj); } catch (e) { /* เปิดนอก extension */ } }
  };

  /* ------------------------------------------------------------------
     States  (ตรงกับ Frame 1-4)
       login = Frame 1 | free = Frame 2 | trial = Frame 3 | paid = Frame 4
     ------------------------------------------------------------------ */
  const STATES = {
    free: {
      active: 'A',
      btnA: ['used', 'Used'],
      btnB: ['trial', 'free trial'],
      tier: 'Free',
      pct: '100%',
      fill: '100%',
      sub: 'Unlimited',
      subRight: 31,
      upg: null,
    },
    trial: {
      active: 'B',
      btnA: ['use', 'Use'],
      btnB: ['used', 'Used'],
      tier: 'free trial',
      pct: '58%',
      fill: '165px',
      sub: '<b>2.8</b> minutes of video left.',
      subRight: 25,
      upg: ['on', 'Upgrade'],
    },
    paid: {
      active: 'B',
      btnA: ['use', 'Use'],
      btnB: ['used', 'Used'],
      tier: 'upgrade tier',
      pct: '69%',
      fill: '200px',
      sub: '<b>132.6</b> minutes of video left, For this day.',
      subRight: 25,
      upg: ['off', 'Expired in 7 days'],
    },
  };

  function setBtn(el, [kind, text]) {
    el.className = 'abs cbtn ' + kind;
    el.textContent = text;
  }

  function setState(name) {
    if (name !== 'login' && !STATES[name]) name = 'login';
    popup.classList.remove('s-login', 's-free', 's-trial', 's-paid');
    popup.classList.add('s-' + name);
    popup.dataset.state = name;
    if (name === 'login') return;

    const s = STATES[name];
    $('cardA').classList.toggle('on', s.active === 'A');
    $('cardB').classList.toggle('on', s.active === 'B');
    setBtn($('btnA'), s.btnA);
    setBtn($('btnB'), s.btnB);

    $('crTier').textContent = s.tier;
    $('crPct').textContent = s.pct;
    $('barFill').style.setProperty('--w', s.fill);

    const sub = $('crSub');
    sub.innerHTML = s.sub;
    sub.style.right = s.subRight + 'px';

    const upg = $('btnUpg');
    if (s.upg) {
      upg.className = 'abs upg ' + s.upg[0];
      upg.textContent = s.upg[1];
    }
  }

  /* ------------------------------------------------------------------
     Login
     ------------------------------------------------------------------ */
  const email = $('email'), pass = $('pass');
  const syncPh = () => {
    $('phEmail').classList.toggle('hide', email.value !== '');
    $('phPass').classList.toggle('hide', pass.value !== '');
  };
  email.addEventListener('input', syncPh);
  pass.addEventListener('input', syncPh);

  $('btnSignIn').addEventListener('click', () => setState('free'));
  $('btnGoogle').addEventListener('click', () => setState('free'));
  $('lnkForget').addEventListener('click', (e) => e.preventDefault());
  pass.addEventListener('keydown', (e) => { if (e.key === 'Enter') setState('free'); });

  /* ------------------------------------------------------------------
     Plan buttons
     ------------------------------------------------------------------ */
  $('btnA').addEventListener('click', () => {
    if ($('btnA').classList.contains('use')) setState('free');
  });
  $('btnB').addEventListener('click', () => {
    if ($('btnB').classList.contains('trial')) setState('trial');
  });
  $('btnUpg').addEventListener('click', () => {
    if ($('btnUpg').classList.contains('on')) setState('paid');
  });

  ['lnkRate', 'lnkSite'].forEach((id) =>
    $(id).addEventListener('click', (e) => e.preventDefault())
  );

  /* ------------------------------------------------------------------
     Dropdowns (ใช้ <select> โปร่งใสซ้อนบนปุ่มทรงแคปซูล)
     ------------------------------------------------------------------ */
  function bindSelect(selId, textId, items, onChange) {
    const sel = $(selId), txt = $(textId);
    items.forEach((o) => {
      const opt = document.createElement('option');
      opt.value = o.value;
      opt.textContent = o.label;
      sel.appendChild(opt);
    });
    const sync = () => { txt.textContent = sel.options[sel.selectedIndex].textContent; };
    sel.addEventListener('change', () => { sync(); if (onChange) onChange(sel.value); });
    sync();
  }
  bindSelect('selFrom', 'fromTxt', FROM_LANGS);
  bindSelect('selTo', 'toTxt', TO_LANGS);
  bindSelect('selVoice', 'voiceTxt', VOICES, (uri) => { if (uri) store.set({ [KEY_VOICE]: uri }); });

  /* รายชื่อเสียง = เสียงที่ติดตั้งในเครื่องผู้ใช้ (เสียงไทยก่อน, ไม่มีไทยจึงแสดงทั้งหมด)
     ใช้เกณฑ์เรียงเดียวกับ dubbing.js เพื่อให้ค่าเริ่มต้นตรงกัน */
  const selVoice = $('selVoice'), voiceTxt = $('voiceTxt');
  async function fillVoices() {
    if (!('speechSynthesis' in window)) return;
    const all = speechSynthesis.getVoices();
    if (!all.length) return;
    const th = all.filter((v) => /^th/i.test(v.lang));
    const list = (th.length ? th : all).slice().sort((a, b) =>
      (b.localService - a.localService) || a.name.localeCompare(b.name));
    const saved = (await store.get(KEY_VOICE))[KEY_VOICE] || '';
    const keep = selVoice.value || saved;
    selVoice.innerHTML = '';
    list.forEach((v) => {
      const o = document.createElement('option');
      o.value = v.voiceURI;
      o.textContent = `${v.name} (${v.lang})${v.localService ? '' : ' · online'}`;
      selVoice.appendChild(o);
    });
    const chosen = list.find((v) => v.voiceURI === keep) || list[0];
    if (chosen) selVoice.value = chosen.voiceURI;
    voiceTxt.textContent = selVoice.options[selVoice.selectedIndex].textContent;
  }
  if ('speechSynthesis' in window) {
    speechSynthesis.addEventListener('voiceschanged', fillVoices);
    fillVoices();
  }

  /* ------------------------------------------------------------------
     Volume sliders
     กล่อง slider กว้าง 138 (ตามรูป), thumb กว้าง 18 รวมขอบม่วง -> วิ่งได้ 120px
     ------------------------------------------------------------------ */
  const TRAVEL = 120;
  const SLIDER_W = 138;

  function makeSlider({ el, pctEl, muteEl, loudEl, value, onChange }) {
    const thumb = el.querySelector('.thumb');
    let v = value;

    const render = () => {
      thumb.style.setProperty('--l', (v / 100) * TRAVEL + 'px');
      pctEl.textContent = Math.round(v) + '%';
    };
    const changed = () => { render(); if (onChange) onChange(Math.round(v)); };

    const fromEvent = (e) => {
      const r = el.getBoundingClientRect();
      const k = r.width / SLIDER_W;               // ชดเชย zoom ของ body
      const x = (e.clientX - r.left) / k - 8;     // กึ่งกลาง thumb
      v = Math.max(0, Math.min(100, (x / TRAVEL) * 100));
      changed();
    };

    el.addEventListener('pointerdown', (e) => {
      el.setPointerCapture(e.pointerId);
      fromEvent(e);
      const move = (ev) => fromEvent(ev);
      const up = () => {
        el.removeEventListener('pointermove', move);
        el.removeEventListener('pointerup', up);
        el.removeEventListener('pointercancel', up);
      };
      el.addEventListener('pointermove', move);
      el.addEventListener('pointerup', up);
      el.addEventListener('pointercancel', up);
    });

    muteEl.addEventListener('click', () => { v = 0; changed(); });
    loudEl.addEventListener('click', () => { v = 100; changed(); });
    render();
    return { set: (n) => { v = Math.max(0, Math.min(100, Number(n) || 0)); render(); } };
  }

  const slVideo = makeSlider({ el: $('slVideo'), pctEl: $('pcVideo'), muteEl: $('vMute'), loudEl: $('vLoud'), value: 0,
    onChange: (n) => store.set({ [KEY_VIDEO]: n }) });
  const slDub = makeSlider({ el: $('slDub'), pctEl: $('pcDub'), muteEl: $('dMute'), loudEl: $('dLoud'), value: 100,
    onChange: (n) => store.set({ [KEY_DUB]: n }) });
  // คืนค่าที่ผู้ใช้เคยตั้งไว้
  store.get([KEY_VIDEO, KEY_DUB]).then((r) => {
    if (r[KEY_VIDEO] != null) slVideo.set(r[KEY_VIDEO]);
    if (r[KEY_DUB] != null) slDub.set(r[KEY_DUB]);
  });

  /* ------------------------------------------------------------------
     เริ่มต้น: Frame 1 (login)
     ดูแต่ละเฟรมตรงๆ ได้ด้วย hash:  sidepanel.html#login | #free | #trial | #paid
     ------------------------------------------------------------------ */
  const initial = (location.hash || '').replace('#', '');
  setState(initial || 'login');
  window.addEventListener('hashchange', () => setState(location.hash.replace('#', '')));
})();
