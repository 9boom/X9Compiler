/* =========================================================
   PAKY Dubbing — content.js  (เชื่อม dubbing.js เข้ากับหน้า YouTube)

   - ปุ่มโลโก้ข้างปุ่ม caption (CC)
   - แสงวิบวับระหว่างโหลด (ถอด transcript + แปล ≥ 5 cue แล้วค่อยเล่น)
   - sync เสียงพากย์กับ timeline จริงของวิดีโอ (seek/pause/buffering/โฆษณา)
   - หลอดเหลืองบน progress bar = cue ที่แปลพร้อมพากย์แล้ว
   - อ่านค่า slider (เสียงวิดีโอ/เสียงพากย์) จาก side panel ผ่าน chrome.storage

   ไม่แก้ logic ของ dubbing.js — ใช้ผ่าน window.PakyDubbing เท่านั้น
========================================================= */
(() => {
  'use strict';
  if (window.__pakyContentLoaded) return;
  window.__pakyContentLoaded = true;

  const D = window.PakyDubbing;
  if (!D) return;

  /* ---------------- config ---------------- */
  const MIN_READY = 5;      // แปลสำเร็จอย่างน้อยกี่ cue ถึงเริ่มเล่น
  const STALL_BELOW = 2;    // เล่นไปแล้วเหลือ cue ที่พร้อมข้างหน้าน้อยกว่านี้ → รอ (เหมือน buffering)
  const DRIFT_MS = 1200;    // เสียงพากย์เพี้ยนจากวิดีโอเกินนี้ → sync ใหม่
  const LOOP_MS = 250;
  const KEY_VIDEO = 'paky:vol-video';
  const KEY_DUB = 'paky:vol-dub';

  const S = {
    mode: 'idle',           // idle | loading | on
    token: 0,
    videoId: '',
    stalled: false,
    resumeAfterStall: false,
    ourPause: false,
    orig: null,             // { volume, muted } ของผู้ใช้ก่อนเปิดพากย์
    vols: { video: 0, dub: 100 },
    lastBufSig: '',
    video: null
  };

  /* ---------------- helpers ---------------- */
  const $ = (s, r = document) => r.querySelector(s);
  const getPlayer = () => document.getElementById('movie_player');
  const getVideo = () =>
    $('#movie_player video.html5-main-video') || $('#movie_player video') || $('video.html5-main-video');
  const isAd = () => { const p = getPlayer(); return !!(p && p.classList.contains('ad-showing')); };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const tts = () => D.tts;
  const cues = () => D.getSegments();
  const isThai = () => /^th/i.test(String(D.getLanguage() || '').replace(/^a\./i, ''));
  const cueReady = (c) => isThai() || !!(c && c.th);

  function curIdx(posMs) {
    const i = tts().indexAt(posMs);
    return i < 0 ? 0 : i;
  }
  function readyAhead(idx) {
    const list = cues();
    let n = 0;
    for (let i = idx; i < list.length; i++) {
      if (!cueReady(list[i])) break;
      n++;
    }
    return n;
  }

  /* ---------------- UI: button ---------------- */
  let btn = null;

  function buildButton() {
    const b = document.createElement('button');
    b.className = 'ytp-button paky-btn';
    b.type = 'button';
    b.setAttribute('aria-label', 'PAKY Dubbing');
    b.title = 'PAKY Dubbing – พากย์เสียงไทย';
    const img = document.createElement('img');
    img.src = chrome.runtime.getURL('assets/logo.png');
    img.alt = '';
    img.draggable = false;
    b.appendChild(img);
    b.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      onButton();
    });
    // กันคีย์ลัด/คลิกของ YouTube ซ้อน
    b.addEventListener('dblclick', (e) => e.stopPropagation());
    return b;
  }

  function paintButton() {
    if (!btn) return;
    btn.classList.toggle('paky-on', S.mode === 'on');
    btn.classList.toggle('paky-loading', S.mode === 'loading' || S.stalled);
    btn.setAttribute('aria-pressed', S.mode === 'on' ? 'true' : 'false');
  }

  function ensureButton() {
    const right = $('.ytp-right-controls');
    if (!right) return;
    if (btn && btn.isConnected && btn.parentElement === right) return;
    if (!btn) btn = buildButton();
    const cc = $('.ytp-subtitles-button', right);
    if (cc) cc.before(btn);          // ข้าง ๆ ปุ่ม caption
    else right.prepend(btn);
    paintButton();
  }

  /* ---------------- UI: shimmer overlay ---------------- */
  let shimmer = null, chipText = null;

  function buildShimmer() {
    const el = document.createElement('div');
    el.id = 'paky-shimmer';
    el.innerHTML =
      '<div class="paky-sweep"></div><div class="paky-sweep paky-sweep2"></div>' +
      '<div class="paky-sparks"></div>' +
      '<div class="paky-chip"><span class="paky-chip-dot"></span><span class="paky-chip-text"></span></div>';
    const sparks = $('.paky-sparks', el);
    for (let i = 0; i < 26; i++) {
      const s = document.createElement('i');
      const size = 8 + Math.random() * 16;
      s.style.cssText =
        `left:${(Math.random() * 96).toFixed(1)}%;top:${(Math.random() * 92).toFixed(1)}%;` +
        `width:${size.toFixed(1)}px;height:${size.toFixed(1)}px;` +
        `animation-delay:${(Math.random() * 2.6).toFixed(2)}s;` +
        `animation-duration:${(1.4 + Math.random() * 1.6).toFixed(2)}s`;
      sparks.appendChild(s);
    }
    chipText = $('.paky-chip-text', el);
    return el;
  }

  function ensureShimmer() {
    const p = getPlayer();
    if (!p) return;
    if (shimmer && shimmer.isConnected && shimmer.parentElement === p) return;
    if (!shimmer) shimmer = buildShimmer();
    p.appendChild(shimmer);
  }

  function showShimmer(text, isError) {
    ensureShimmer();
    if (!shimmer) return;
    chipText.textContent = text || '';
    shimmer.classList.toggle('paky-err', !!isError);
    shimmer.classList.add('paky-show');
  }
  function setShimmerText(text) { if (chipText) chipText.textContent = text; }
  function hideShimmer() { if (shimmer) shimmer.classList.remove('paky-show', 'paky-err'); }

  /* ---------------- UI: yellow buffer bar ---------------- */
  let buf = null;

  function ensureBuf() {
    const bar = $('.ytp-progress-bar');
    if (!bar) return null;
    if (buf && buf.isConnected && buf.parentElement === bar) return buf;
    if (!buf) { buf = document.createElement('div'); buf.className = 'paky-buf'; }
    bar.appendChild(buf);
    S.lastBufSig = '';
    return buf;
  }

  /* ช่วงเวลา (ms) ที่ cue แปลพร้อมแล้ว — รวม cue ที่ติดกัน */
  function readyRanges() {
    const list = cues();
    const out = [];
    let a = -1, b = -1;
    for (let i = 0; i < list.length; i++) {
      const c = list[i];
      if (cueReady(c)) {
        const next = list[i + 1];
        const end = next && next.start > c.start ? Math.max(next.start, c.start + c.dur) : c.start + c.dur;
        if (a < 0) a = c.start;
        b = end;
        if (!next || !cueReady(next)) { out.push([a, b]); a = -1; }
      } else if (a >= 0) { out.push([a, b]); a = -1; }
    }
    return out;
  }

  function renderBuffer() {
    const v = S.video;
    if (S.mode === 'idle' || !v) { if (buf) { buf.textContent = ''; S.lastBufSig = ''; } return; }
    const el = ensureBuf();
    if (!el) return;
    const dur = isFinite(v.duration) && v.duration > 0 ? v.duration * 1000 : tts().total();
    if (!dur) return;
    const pos = v.currentTime * 1000;
    // ครอบเฉพาะช่วง "ข้างหน้า" playhead เหมือน buffer ของ YouTube (ด้านหลังถูกแถบแดงทับอยู่แล้ว)
    const segs = readyRanges()
      .map(([a, b]) => [Math.max(a, pos), Math.min(b, dur)])
      .filter(([a, b]) => b > a);
    const list = $('.ytp-progress-list');
    const barRect = el.parentElement.getBoundingClientRect();
    const listRect = list ? list.getBoundingClientRect() : null;
    const top = listRect ? Math.round(listRect.top - barRect.top) : 0;
    const height = listRect ? Math.max(2, Math.round(listRect.height)) : 3;
    const sig = segs.map(([a, b]) => `${(a / dur * 1000) | 0}-${(b / dur * 1000) | 0}`).join('|') + `@${top}/${height}`;
    if (sig === S.lastBufSig) return;
    S.lastBufSig = sig;
    el.style.top = top + 'px';
    el.style.height = height + 'px';
    el.textContent = '';
    for (const [a, b] of segs) {
      const s = document.createElement('div');
      s.className = 'paky-buf-seg';
      s.style.left = (a / dur * 100).toFixed(3) + '%';
      s.style.width = ((b - a) / dur * 100).toFixed(3) + '%';
      el.appendChild(s);
    }
  }

  /* ---------------- volumes ---------------- */
  function applyDubVolume() {
    if (D.tts) tts().setVolume(S.vols.dub / 100);
  }
  function enforceVideoVolume() {
    const v = S.video;
    if (!v || S.mode !== 'on') return;
    if (isAd()) { restoreVideoVolume(); return; }   // โฆษณาให้ได้ยินเสียงตามที่ผู้ใช้ตั้งไว้เดิม
    const target = Math.max(0, Math.min(1, S.vols.video / 100));
    if (Math.abs(v.volume - target) > 0.005) v.volume = target;
    if (v.muted) v.muted = false;
  }
  function restoreVideoVolume() {
    const v = S.video;
    if (!v || !S.orig) return;
    if (Math.abs(v.volume - S.orig.volume) > 0.005) v.volume = S.orig.volume;
    if (v.muted !== S.orig.muted) v.muted = S.orig.muted;
  }

  function loadSettings() {
    try {
      chrome.storage.local.get([KEY_VIDEO, KEY_DUB]).then((r) => {
        if (r[KEY_VIDEO] != null) S.vols.video = Number(r[KEY_VIDEO]);
        if (r[KEY_DUB] != null) S.vols.dub = Number(r[KEY_DUB]);
        applyDubVolume();
      });
      chrome.storage.onChanged.addListener((ch, area) => {
        if (area !== 'local') return;
        if (ch[KEY_VIDEO]) S.vols.video = Number(ch[KEY_VIDEO].newValue);
        if (ch[KEY_DUB]) S.vols.dub = Number(ch[KEY_DUB].newValue);
        applyDubVolume();
        enforceVideoVolume();
      });
    } catch (e) { /* ใช้ค่าเริ่มต้น */ }
  }

  /* ---------------- translation priority ---------------- */
  let prioBusy = false;
  async function prioritize(idx) {
    if (prioBusy || isThai()) return;
    prioBusy = true;
    try {
      const t = tts();
      if (t.isTranslating()) {
        t.abortTranslate();
        // รอ request ที่ค้างอยู่จบ (worker ออกจากลูปเอง) — นานสุด ~20 วินาที
        for (let k = 0; k < 400 && t.isTranslating(); k++) await sleep(50);
      }
      if (!t.isTranslating() && cues().some((c) => !c.th)) t.translateAll(idx);
    } finally { prioBusy = false; }
  }

  async function waitTranslateIdle() {
    const t = tts();
    for (let k = 0; k < 60 && t.isTranslating(); k++) await sleep(50);
  }

  /* ---------------- sync (หัวใจ: timeline เสียงพากย์ = timeline วิดีโอ) ---------------- */
  function setStalled(on) {
    if (on === S.stalled) return;
    S.stalled = on;
    const v = S.video;
    if (on) {
      showShimmer('กำลังแปลต่อ… รอสักครู่');
      if (v && !v.paused) { S.ourPause = true; S.resumeAfterStall = true; v.pause(); }
    } else {
      hideShimmer();
      if (S.resumeAfterStall && v) { S.resumeAfterStall = false; v.play().catch(() => {}); }
    }
    paintButton();
  }

  function reconcile() {
    if (S.mode !== 'on') return;
    const v = S.video;
    if (!v || !tts()) return;
    enforceVideoVolume();
    tts().setClock(v.playbackRate);          // เสียงพากย์เดินตามความเร็วของวิดีโอ (1.25x, 1.5x, 2x ...)

    const posMs = v.currentTime * 1000;
    const total = cues().length;

    // --- รอแปลทัน (เหมือน buffering ของ YouTube) ---
    if (!isThai() && tts().isTranslating()) {
      const idx = curIdx(posMs);
      const a = readyAhead(idx);
      const left = total - idx;
      if (!S.stalled && a < Math.min(STALL_BELOW, left)) setStalled(true);
      else if (S.stalled && a >= Math.min(MIN_READY, left)) setStalled(false);
    } else if (S.stalled) {
      setStalled(false);
    }
    if (S.stalled && !v.paused) { S.ourPause = true; S.resumeAfterStall = true; v.pause(); }

    // --- ควรให้เสียงพากย์เล่นอยู่ไหม ---
    const want =
      !v.paused && !v.seeking && !v.ended && v.readyState >= 3 &&
      !S.stalled && !isAd();

    const t = tts();
    if (want) {
      if (!t.isPlaying()) {
        if (!t.isBusy() && posMs < t.total() - 100) {
          t.seek(posMs);
          t.play();
        }
      } else if (Math.abs(t.getPos() - posMs) > DRIFT_MS) {
        t.seek(posMs);                       // ผู้ใช้ scroll/กระโดด หรือวิดีโอสะดุด → ตามให้ตรง
      }
    } else if (t.isPlaying()) {
      t.pause();
    }
  }

  function bindVideo(v) {
    if (S.video === v) return;
    if (S.video) unbindVideo(S.video);
    S.video = v;
    v.addEventListener('play', onVideoEvt);
    v.addEventListener('playing', onVideoEvt);
    v.addEventListener('pause', onVideoPause);
    v.addEventListener('waiting', onVideoEvt);
    v.addEventListener('seeking', onVideoEvt);
    v.addEventListener('seeked', onSeeked);
    v.addEventListener('ratechange', onRate);
    v.addEventListener('ended', onVideoEvt);
    v.addEventListener('emptied', onVideoEvt);
  }
  function unbindVideo(v) {
    for (const [n, f] of [['play', onVideoEvt], ['playing', onVideoEvt], ['pause', onVideoPause],
      ['waiting', onVideoEvt], ['seeking', onVideoEvt], ['seeked', onSeeked], ['ratechange', onRate],
      ['ended', onVideoEvt], ['emptied', onVideoEvt]]) v.removeEventListener(n, f);
  }

  function onVideoEvt() { reconcile(); }
  function onVideoPause() {
    if (S.ourPause) S.ourPause = false;
    else if (S.stalled) S.resumeAfterStall = false;   // ผู้ใช้กดหยุดเองระหว่างรอ → ไม่ต้องเล่นต่ออัตโนมัติ
    reconcile();
  }
  function onRate() { reconcile(); }
  function onSeeked() {
    if (S.mode === 'on' && D.tts && !isThai()) {
      const idx = curIdx(S.video.currentTime * 1000);
      if (!cueReady(cues()[idx]) || !cueReady(cues()[idx + 1])) prioritize(idx);   // กระโดดไปช่วงที่ยังไม่แปล → แปลช่วงนั้นก่อน
    }
    reconcile();
  }

  /* ---------------- start / stop ---------------- */
  async function onButton() {
    if (S.mode === 'idle') return start();
    return stop();
  }

  async function start() {
    const token = ++S.token;
    const v = getVideo();
    const videoId = D.getVideoId(location.href);
    if (!v || !videoId) return;
    bindVideo(v);
    S.mode = 'loading';
    S.videoId = videoId;
    S.stalled = false;
    paintButton();
    showShimmer('กำลังถอดเสียง (transcript)…');

    const wasPlaying = !v.paused;
    if (wasPlaying) { S.ourPause = true; v.pause(); }
    const fail = (msg) => {
      if (token !== S.token) return;
      S.mode = 'idle';
      paintButton();
      showShimmer(msg, true);
      setTimeout(() => { if (S.mode === 'idle') hideShimmer(); }, 3500);
      if (wasPlaying) v.play().catch(() => {});
    };

    try {
      const t = tts();
      if (!t.supported) return fail('เบราว์เซอร์นี้ไม่รองรับ speechSynthesis');

      // 1) ถอด transcript (ใช้ซ้ำถ้าเป็นคลิปเดิมที่เคยโหลดแล้ว)
      if (D.getVideoIdLoaded() !== videoId || !cues().length) {
        await waitTranslateIdle();
        await D.loadTranscript(videoId);
      }
      if (token !== S.token) return;
      if (!cues().length) return fail('ไม่พบ transcript ของคลิปนี้');

      // 2) เริ่มแปลจาก cue ที่ตำแหน่งปัจจุบัน
      const startIdx = curIdx(v.currentTime * 1000);
      const need = Math.min(MIN_READY, cues().length - startIdx);
      if (!isThai()) {
        await waitTranslateIdle();
        t.translateAll(startIdx);
      }

      // 3) รอ voice + calibrate (ครั้งแรกต่อเสียง ~5 วินาที) ไปพร้อมกับการแปล
      for (let k = 0; k < 40 && !t.hasVoice(); k++) await sleep(100);
      const calibrating = t.prepare();

      // 4) รอให้แปลสำเร็จ ≥ 5 cue
      setShimmerText(`กำลังแปล 0/${need}`);
      for (;;) {
        if (token !== S.token) return;
        const a = readyAhead(startIdx);
        setShimmerText(`กำลังแปล ${Math.min(a, need)}/${need}`);
        if (a >= need) break;
        if (!isThai() && !t.isTranslating()) {
          if (a > 0) break;                       // แปลจบ/หยุดแล้วแต่ได้บางส่วน → ไปต่อ
          return fail('แปลไม่สำเร็จ — ตรวจสอบอินเทอร์เน็ตแล้วลองใหม่');
        }
        await sleep(150);
      }
      setShimmerText('กำลังปรับเสียง…');
      await calibrating;
      if (token !== S.token) return;

      // 5) เริ่มเล่น
      S.orig = { volume: v.volume, muted: v.muted };
      S.mode = 'on';
      applyDubVolume();
      enforceVideoVolume();
      hideShimmer();
      paintButton();
      S.lastBufSig = '';
      renderBuffer();
      v.play().catch(() => {});
      reconcile();
    } catch (e) {
      console.error('[PAKY]', e);
      fail(D.friendlyError(e));
    }
  }

  function stop() {
    S.token++;
    const wasOn = S.mode !== 'idle';
    S.mode = 'idle';
    S.resumeAfterStall = false;
    S.stalled = false;
    if (D.tts) {
      tts().abortTranslate();
      if (tts().isPlaying()) tts().pause();
    }
    if (wasOn) restoreVideoVolume();
    S.orig = null;
    hideShimmer();
    renderBuffer();
    paintButton();
  }

  /* ---------------- lifecycle ---------------- */
  function tickUI() {
    ensureButton();
    const v = getVideo();
    if (v && v !== S.video) {
      if (S.mode !== 'idle') stop();
      bindVideo(v);
    }
    const vid = D.getVideoId(location.href);
    if (S.mode !== 'idle' && vid !== S.videoId) stop();   // เปลี่ยนคลิป (SPA) → ปิดพากย์ของคลิปเดิม
    if (S.mode === 'on') {
      reconcile();
      renderBuffer();
    }
  }

  async function boot() {
    await D.init();
    loadSettings();
    applyDubVolume();
    const v = getVideo();
    if (v) bindVideo(v);
    setInterval(tickUI, LOOP_MS);
    document.addEventListener('yt-navigate-finish', () => { ensureButton(); ensureShimmer(); });
    window.addEventListener('pagehide', () => { if (S.mode !== 'idle') stop(); });
    tickUI();
  }

  boot().catch((e) => console.error('[PAKY] boot failed', e));
})();
